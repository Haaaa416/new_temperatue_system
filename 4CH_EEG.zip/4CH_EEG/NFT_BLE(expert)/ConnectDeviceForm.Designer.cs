﻿namespace NFT_BLE_expert_
{
    partial class ConnectDeviceForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.panelLeft = new System.Windows.Forms.Panel();
            this.lblPatientDetails = new System.Windows.Forms.Label();
            this.panelPatientInfo = new System.Windows.Forms.Panel();
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.lblPatientName = new System.Windows.Forms.Label();
            this.lblPatientId = new System.Windows.Forms.Label();
            this.panelDetails = new System.Windows.Forms.Panel();
            this.lblAgeLabel = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblGenderLabel = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblBloodTypeLabel = new System.Windows.Forms.Label();
            this.lblBloodType = new System.Windows.Forms.Label();
            this.lblHeightLabel = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblWeightLabel = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.panelRecentVisits = new System.Windows.Forms.Panel();
            this.lblRecentVisits = new System.Windows.Forms.Label();
            this.lblSelectedPart = new System.Windows.Forms.Label();
            this.lblSelectedDate = new System.Windows.Forms.Label();
            this.lblExposureTime = new System.Windows.Forms.Label();
            this.cmbExposureTime = new System.Windows.Forms.ComboBox();
            this.txtCustomTime = new System.Windows.Forms.TextBox();
            this.lblCustomMinutes = new System.Windows.Forms.Label();
            this.lblCurrentSetting = new System.Windows.Forms.Label();

            this.panelRight = new System.Windows.Forms.Panel();
            this.lblWaveform = new System.Windows.Forms.Label();
            this.lblCZ = new System.Windows.Forms.Label();
            this.panelChartCZ = new System.Windows.Forms.Panel();
            this.lblMaxCZ = new System.Windows.Forms.Label();
            this.txtMaxCZ = new System.Windows.Forms.TextBox();
            this.lblMinCZ = new System.Windows.Forms.Label();
            this.txtMinCZ = new System.Windows.Forms.TextBox();

            this.lblFZ = new System.Windows.Forms.Label();
            this.panelChartFZ = new System.Windows.Forms.Panel();
            this.lblMaxFZ = new System.Windows.Forms.Label();
            this.txtMaxFZ = new System.Windows.Forms.TextBox();
            this.lblMinFZ = new System.Windows.Forms.Label();
            this.txtMinFZ = new System.Windows.Forms.TextBox();

            this.btnUpdateRange = new System.Windows.Forms.Button();
            this.cmbComport = new System.Windows.Forms.ComboBox();
            this.btnSearchDevice = new System.Windows.Forms.Button();
            this.btnConnectDevice = new System.Windows.Forms.Button();
            this.lblDeviceStatus = new System.Windows.Forms.Label();
            this.btnStartTreatment = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();

            this.panelLeft.SuspendLayout();
            this.panelPatientInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();
            this.panelDetails.SuspendLayout();
            this.panelRecentVisits.SuspendLayout();
            this.panelRight.SuspendLayout();
            this.SuspendLayout();

            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(20, 15);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(80, 30);
            this.btnBack.TabIndex = 0;
            this.btnBack.Text = "← Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);

            // 
            // panelLeft
            // 
            this.panelLeft.BackColor = System.Drawing.Color.White;
            this.panelLeft.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelLeft.Controls.Add(this.lblPatientDetails);
            this.panelLeft.Controls.Add(this.panelPatientInfo);
            this.panelLeft.Controls.Add(this.panelDetails);
            this.panelLeft.Controls.Add(this.panelRecentVisits);
            this.panelLeft.Location = new System.Drawing.Point(20, 60);
            this.panelLeft.Name = "panelLeft";
            this.panelLeft.Size = new System.Drawing.Size(360, 780);
            this.panelLeft.TabIndex = 1;

            // 
            // lblPatientDetails
            // 
            this.lblPatientDetails.AutoSize = true;
            this.lblPatientDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.lblPatientDetails.Location = new System.Drawing.Point(10, 10);
            this.lblPatientDetails.Name = "lblPatientDetails";
            this.lblPatientDetails.Size = new System.Drawing.Size(180, 26);
            this.lblPatientDetails.TabIndex = 0;
            this.lblPatientDetails.Text = "Patient Details";

            // 
            // panelPatientInfo
            // 
            this.panelPatientInfo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelPatientInfo.Controls.Add(this.picAvatar);
            this.panelPatientInfo.Controls.Add(this.lblPatientName);
            this.panelPatientInfo.Controls.Add(this.lblPatientId);
            this.panelPatientInfo.Location = new System.Drawing.Point(10, 50);
            this.panelPatientInfo.Name = "panelPatientInfo";
            this.panelPatientInfo.Size = new System.Drawing.Size(330, 80);
            this.panelPatientInfo.TabIndex = 1;

            // 
            // picAvatar
            // 
            this.picAvatar.Location = new System.Drawing.Point(10, 10);
            this.picAvatar.Name = "picAvatar";
            this.picAvatar.Size = new System.Drawing.Size(52, 52);
            this.picAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picAvatar.TabIndex = 0;
            this.picAvatar.TabStop = false;

            // 
            // lblPatientName
            // 
            this.lblPatientName.AutoSize = true;
            this.lblPatientName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblPatientName.Location = new System.Drawing.Point(75, 15);
            this.lblPatientName.Name = "lblPatientName";
            this.lblPatientName.Size = new System.Drawing.Size(110, 17);
            this.lblPatientName.TabIndex = 1;
            this.lblPatientName.Text = "Patient Name";

            // 
            // lblPatientId
            // 
            this.lblPatientId.AutoSize = true;
            this.lblPatientId.ForeColor = System.Drawing.Color.Gray;
            this.lblPatientId.Location = new System.Drawing.Point(75, 40);
            this.lblPatientId.Name = "lblPatientId";
            this.lblPatientId.Size = new System.Drawing.Size(100, 13);
            this.lblPatientId.TabIndex = 2;
            this.lblPatientId.Text = "ID: PAT-2023-1296";

            // 
            // panelDetails
            // 
            this.panelDetails.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelDetails.Controls.Add(this.lblAgeLabel);
            this.panelDetails.Controls.Add(this.lblAge);
            this.panelDetails.Controls.Add(this.lblGenderLabel);
            this.panelDetails.Controls.Add(this.lblGender);
            this.panelDetails.Controls.Add(this.lblBloodTypeLabel);
            this.panelDetails.Controls.Add(this.lblBloodType);
            this.panelDetails.Controls.Add(this.lblHeightLabel);
            this.panelDetails.Controls.Add(this.lblHeight);
            this.panelDetails.Controls.Add(this.lblWeightLabel);
            this.panelDetails.Controls.Add(this.lblWeight);
            this.panelDetails.Location = new System.Drawing.Point(10, 140);
            this.panelDetails.Name = "panelDetails";
            this.panelDetails.Size = new System.Drawing.Size(330, 150);
            this.panelDetails.TabIndex = 2;

            // 
            // lblAgeLabel
            // 
            this.lblAgeLabel.AutoSize = true;
            this.lblAgeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblAgeLabel.Location = new System.Drawing.Point(10, 10);
            this.lblAgeLabel.Name = "lblAgeLabel";
            this.lblAgeLabel.Size = new System.Drawing.Size(33, 15);
            this.lblAgeLabel.TabIndex = 0;
            this.lblAgeLabel.Text = "Age";

            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.ForeColor = System.Drawing.Color.Gray;
            this.lblAge.Location = new System.Drawing.Point(260, 10);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(19, 13);
            this.lblAge.TabIndex = 1;
            this.lblAge.Text = "35";

            // 
            // lblGenderLabel
            // 
            this.lblGenderLabel.AutoSize = true;
            this.lblGenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblGenderLabel.Location = new System.Drawing.Point(10, 40);
            this.lblGenderLabel.Name = "lblGenderLabel";
            this.lblGenderLabel.Size = new System.Drawing.Size(54, 15);
            this.lblGenderLabel.TabIndex = 2;
            this.lblGenderLabel.Text = "Gender";

            // 
            // lblGender
            // 
            this.lblGender.AutoSize = true;
            this.lblGender.ForeColor = System.Drawing.Color.Gray;
            this.lblGender.Location = new System.Drawing.Point(260, 40);
            this.lblGender.Name = "lblGender";
            this.lblGender.Size = new System.Drawing.Size(33, 13);
            this.lblGender.TabIndex = 3;
            this.lblGender.Text = "Male";

            // 
            // lblBloodTypeLabel
            // 
            this.lblBloodTypeLabel.AutoSize = true;
            this.lblBloodTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblBloodTypeLabel.Location = new System.Drawing.Point(10, 70);
            this.lblBloodTypeLabel.Name = "lblBloodTypeLabel";
            this.lblBloodTypeLabel.Size = new System.Drawing.Size(80, 15);
            this.lblBloodTypeLabel.TabIndex = 4;
            this.lblBloodTypeLabel.Text = "Blood Type";

            // 
            // lblBloodType
            // 
            this.lblBloodType.AutoSize = true;
            this.lblBloodType.ForeColor = System.Drawing.Color.Gray;
            this.lblBloodType.Location = new System.Drawing.Point(260, 70);
            this.lblBloodType.Name = "lblBloodType";
            this.lblBloodType.Size = new System.Drawing.Size(14, 13);
            this.lblBloodType.TabIndex = 5;
            this.lblBloodType.Text = "A";

            // 
            // lblHeightLabel
            // 
            this.lblHeightLabel.AutoSize = true;
            this.lblHeightLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblHeightLabel.Location = new System.Drawing.Point(10, 100);
            this.lblHeightLabel.Name = "lblHeightLabel";
            this.lblHeightLabel.Size = new System.Drawing.Size(85, 15);
            this.lblHeightLabel.TabIndex = 6;
            this.lblHeightLabel.Text = "Height(cm)";

            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.ForeColor = System.Drawing.Color.Gray;
            this.lblHeight.Location = new System.Drawing.Point(260, 100);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(25, 13);
            this.lblHeight.TabIndex = 7;
            this.lblHeight.Text = "178";

            // 
            // lblWeightLabel
            // 
            this.lblWeightLabel.AutoSize = true;
            this.lblWeightLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.lblWeightLabel.Location = new System.Drawing.Point(10, 130);
            this.lblWeightLabel.Name = "lblWeightLabel";
            this.lblWeightLabel.Size = new System.Drawing.Size(85, 15);
            this.lblWeightLabel.TabIndex = 8;
            this.lblWeightLabel.Text = "Weight(kg)";

            // 
            // lblWeight
            // 
            this.lblWeight.AutoSize = true;
            this.lblWeight.ForeColor = System.Drawing.Color.Gray;
            this.lblWeight.Location = new System.Drawing.Point(260, 130);
            this.lblWeight.Name = "lblWeight";
            this.lblWeight.Size = new System.Drawing.Size(19, 13);
            this.lblWeight.TabIndex = 9;
            this.lblWeight.Text = "75";

            // 
            // panelRecentVisits
            // 
            this.panelRecentVisits.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRecentVisits.Controls.Add(this.lblRecentVisits);
            this.panelRecentVisits.Controls.Add(this.lblSelectedPart);
            this.panelRecentVisits.Controls.Add(this.lblSelectedDate);
            this.panelRecentVisits.Controls.Add(this.lblExposureTime);
            this.panelRecentVisits.Controls.Add(this.cmbExposureTime);
            this.panelRecentVisits.Controls.Add(this.txtCustomTime);
            this.panelRecentVisits.Controls.Add(this.lblCustomMinutes);
            this.panelRecentVisits.Controls.Add(this.lblCurrentSetting);
            this.panelRecentVisits.Location = new System.Drawing.Point(10, 300);
            this.panelRecentVisits.Name = "panelRecentVisits";
            this.panelRecentVisits.Size = new System.Drawing.Size(330, 460);
            this.panelRecentVisits.TabIndex = 3;

            // 
            // lblRecentVisits
            // 
            this.lblRecentVisits.AutoSize = true;
            this.lblRecentVisits.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.lblRecentVisits.Location = new System.Drawing.Point(10, 10);
            this.lblRecentVisits.Name = "lblRecentVisits";
            this.lblRecentVisits.Size = new System.Drawing.Size(126, 20);
            this.lblRecentVisits.TabIndex = 0;
            this.lblRecentVisits.Text = "Recent Visits";

            // 
            // lblSelectedPart
            // 
            this.lblSelectedPart.AutoSize = true;
            this.lblSelectedPart.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblSelectedPart.Location = new System.Drawing.Point(10, 280);
            this.lblSelectedPart.Name = "lblSelectedPart";
            this.lblSelectedPart.Size = new System.Drawing.Size(150, 17);
            this.lblSelectedPart.TabIndex = 1;
            this.lblSelectedPart.Text = "10月 15, 2025 – ";

            // 
            // lblSelectedDate
            // 
            this.lblSelectedDate.AutoSize = true;
            this.lblSelectedDate.Location = new System.Drawing.Point(10, 50);
            this.lblSelectedDate.Name = "lblSelectedDate";
            this.lblSelectedDate.Size = new System.Drawing.Size(100, 13);
            this.lblSelectedDate.TabIndex = 2;
            this.lblSelectedDate.Text = "• 10月 15, 2025";

            // 
            // lblExposureTime
            // 
            this.lblExposureTime.AutoSize = true;
            this.lblExposureTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblExposureTime.Location = new System.Drawing.Point(10, 320);
            this.lblExposureTime.Name = "lblExposureTime";
            this.lblExposureTime.Size = new System.Drawing.Size(180, 15);
            this.lblExposureTime.TabIndex = 3;
            this.lblExposureTime.Text = "Exposure Time (per session):";

            // 
            // cmbExposureTime
            // 
            this.cmbExposureTime.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbExposureTime.FormattingEnabled = true;
            this.cmbExposureTime.Items.AddRange(new object[] {
            "5 min",
            "10 min",
            "15 min",
            "20 min",
            "25 min",
            "30 min",
            "Custom…"});
            this.cmbExposureTime.Location = new System.Drawing.Point(10, 345);
            this.cmbExposureTime.Name = "cmbExposureTime";
            this.cmbExposureTime.Size = new System.Drawing.Size(205, 21);
            this.cmbExposureTime.TabIndex = 4;
            this.cmbExposureTime.SelectedIndex = 2;

            // 
            // txtCustomTime
            // 
            this.txtCustomTime.Enabled = false;
            this.txtCustomTime.Location = new System.Drawing.Point(10, 375);
            this.txtCustomTime.Name = "txtCustomTime";
            this.txtCustomTime.Size = new System.Drawing.Size(110, 20);
            this.txtCustomTime.TabIndex = 5;

            // 
            // lblCustomMinutes
            // 
            this.lblCustomMinutes.AutoSize = true;
            this.lblCustomMinutes.Location = new System.Drawing.Point(130, 378);
            this.lblCustomMinutes.Name = "lblCustomMinutes";
            this.lblCustomMinutes.Size = new System.Drawing.Size(25, 13);
            this.lblCustomMinutes.TabIndex = 6;
            this.lblCustomMinutes.Text = "min";

            // 
            // lblCurrentSetting
            // 
            this.lblCurrentSetting.AutoSize = true;
            this.lblCurrentSetting.Location = new System.Drawing.Point(10, 410);
            this.lblCurrentSetting.Name = "lblCurrentSetting";
            this.lblCurrentSetting.Size = new System.Drawing.Size(120, 13);
            this.lblCurrentSetting.TabIndex = 7;
            this.lblCurrentSetting.Text = "目前設定：15 min";

            // 
            // panelRight
            // 
            this.panelRight.BackColor = System.Drawing.Color.White;
            this.panelRight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRight.Controls.Add(this.lblWaveform);
            this.panelRight.Controls.Add(this.lblCZ);
            this.panelRight.Controls.Add(this.panelChartCZ);
            this.panelRight.Controls.Add(this.lblMaxCZ);
            this.panelRight.Controls.Add(this.txtMaxCZ);
            this.panelRight.Controls.Add(this.lblMinCZ);
            this.panelRight.Controls.Add(this.txtMinCZ);
            this.panelRight.Controls.Add(this.lblFZ);
            this.panelRight.Controls.Add(this.panelChartFZ);
            this.panelRight.Controls.Add(this.lblMaxFZ);
            this.panelRight.Controls.Add(this.txtMaxFZ);
            this.panelRight.Controls.Add(this.lblMinFZ);
            this.panelRight.Controls.Add(this.txtMinFZ);
            this.panelRight.Controls.Add(this.btnUpdateRange);
            this.panelRight.Controls.Add(this.cmbComport);
            this.panelRight.Controls.Add(this.btnSearchDevice);
            this.panelRight.Controls.Add(this.btnConnectDevice);
            this.panelRight.Controls.Add(this.lblDeviceStatus);
            this.panelRight.Controls.Add(this.btnStartTreatment);
            this.panelRight.Location = new System.Drawing.Point(800, 60);
            this.panelRight.Name = "panelRight";
            this.panelRight.Size = new System.Drawing.Size(700, 780);
            this.panelRight.TabIndex = 2;

            // 
            // lblWaveform
            // 
            this.lblWaveform.AutoSize = true;
            this.lblWaveform.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.lblWaveform.Location = new System.Drawing.Point(10, 10);
            this.lblWaveform.Name = "lblWaveform";
            this.lblWaveform.Size = new System.Drawing.Size(122, 26);
            this.lblWaveform.TabIndex = 0;
            this.lblWaveform.Text = "Waveform";

            // 
            // lblCZ
            // 
            this.lblCZ.AutoSize = true;
            this.lblCZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblCZ.Location = new System.Drawing.Point(10, 50);
            this.lblCZ.Name = "lblCZ";
            this.lblCZ.Size = new System.Drawing.Size(170, 18);
            this.lblCZ.TabIndex = 1;
            this.lblCZ.Text = "EEG Waveform - CZ";

            // 
            // panelChartCZ
            // 
            this.panelChartCZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelChartCZ.Location = new System.Drawing.Point(10, 80);
            this.panelChartCZ.Name = "panelChartCZ";
            this.panelChartCZ.Size = new System.Drawing.Size(550, 120);
            this.panelChartCZ.TabIndex = 2;

            // 
            // lblMaxCZ
            // 
            this.lblMaxCZ.AutoSize = true;
            this.lblMaxCZ.Location = new System.Drawing.Point(575, 80);
            this.lblMaxCZ.Name = "lblMaxCZ";
            this.lblMaxCZ.Size = new System.Drawing.Size(33, 13);
            this.lblMaxCZ.TabIndex = 3;
            this.lblMaxCZ.Text = "MAX";

            // 
            // txtMaxCZ
            // 
            this.txtMaxCZ.Location = new System.Drawing.Point(575, 100);
            this.txtMaxCZ.Name = "txtMaxCZ";
            this.txtMaxCZ.Size = new System.Drawing.Size(65, 20);
            this.txtMaxCZ.TabIndex = 4;
            this.txtMaxCZ.Text = "500";

            // 
            // lblMinCZ
            // 
            this.lblMinCZ.AutoSize = true;
            this.lblMinCZ.Location = new System.Drawing.Point(575, 130);
            this.lblMinCZ.Name = "lblMinCZ";
            this.lblMinCZ.Size = new System.Drawing.Size(30, 13);
            this.lblMinCZ.TabIndex = 5;
            this.lblMinCZ.Text = "MIN";

            // 
            // txtMinCZ
            // 
            this.txtMinCZ.Location = new System.Drawing.Point(575, 150);
            this.txtMinCZ.Name = "txtMinCZ";
            this.txtMinCZ.Size = new System.Drawing.Size(65, 20);
            this.txtMinCZ.TabIndex = 6;
            this.txtMinCZ.Text = "-500";

            // 
            // lblFZ
            // 
            this.lblFZ.AutoSize = true;
            this.lblFZ.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.lblFZ.Location = new System.Drawing.Point(10, 220);
            this.lblFZ.Name = "lblFZ";
            this.lblFZ.Size = new System.Drawing.Size(170, 18);
            this.lblFZ.TabIndex = 7;
            this.lblFZ.Text = "EEG Waveform - FZ";

            // 
            // panelChartFZ
            // 
            this.panelChartFZ.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelChartFZ.Location = new System.Drawing.Point(10, 250);
            this.panelChartFZ.Name = "panelChartFZ";
            this.panelChartFZ.Size = new System.Drawing.Size(550, 120);
            this.panelChartFZ.TabIndex = 8;

            // 
            // lblMaxFZ
            // 
            this.lblMaxFZ.AutoSize = true;
            this.lblMaxFZ.Location = new System.Drawing.Point(575, 250);
            this.lblMaxFZ.Name = "lblMaxFZ";
            this.lblMaxFZ.Size = new System.Drawing.Size(33, 13);
            this.lblMaxFZ.TabIndex = 9;
            this.lblMaxFZ.Text = "MAX";

            // 
            // txtMaxFZ
            // 
            this.txtMaxFZ.Location = new System.Drawing.Point(575, 270);
            this.txtMaxFZ.Name = "txtMaxFZ";
            this.txtMaxFZ.Size = new System.Drawing.Size(65, 20);
            this.txtMaxFZ.TabIndex = 10;
            this.txtMaxFZ.Text = "500";

            // 
            // lblMinFZ
            // 
            this.lblMinFZ.AutoSize = true;
            this.lblMinFZ.Location = new System.Drawing.Point(575, 300);
            this.lblMinFZ.Name = "lblMinFZ";
            this.lblMinFZ.Size = new System.Drawing.Size(30, 13);
            this.lblMinFZ.TabIndex = 11;
            this.lblMinFZ.Text = "MIN";

            // 
            // txtMinFZ
            // 
            this.txtMinFZ.Location = new System.Drawing.Point(575, 320);
            this.txtMinFZ.Name = "txtMinFZ";
            this.txtMinFZ.Size = new System.Drawing.Size(65, 20);
            this.txtMinFZ.TabIndex = 12;
            this.txtMinFZ.Text = "-500";

            // 
            // btnUpdateRange
            // 
            this.btnUpdateRange.Location = new System.Drawing.Point(560, 390);
            this.btnUpdateRange.Name = "btnUpdateRange";
            this.btnUpdateRange.Size = new System.Drawing.Size(100, 29);
            this.btnUpdateRange.TabIndex = 13;
            this.btnUpdateRange.Text = "SETTING";
            this.btnUpdateRange.UseVisualStyleBackColor = true;
            this.btnUpdateRange.Click += new System.EventHandler(this.btnUpdateRange_Click);

            // 
            // cmbComport
            // 
            this.cmbComport.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbComport.FormattingEnabled = true;
            this.cmbComport.Location = new System.Drawing.Point(10, 460);
            this.cmbComport.Name = "cmbComport";
            this.cmbComport.Size = new System.Drawing.Size(200, 21);
            this.cmbComport.TabIndex = 14;

            // 
            // btnSearchDevice
            // this.btnSearchDevice.BackgroundImage = global::NFT_BLE_expert_.Properties.Resources.search;
            this.btnSearchDevice.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSearchDevice.Location = new System.Drawing.Point(220, 460);
            this.btnSearchDevice.Name = "btnSearchDevice";
            this.btnSearchDevice.Size = new System.Drawing.Size(30, 25);
            this.btnSearchDevice.TabIndex = 15;
            this.btnSearchDevice.UseVisualStyleBackColor = true;
            this.btnSearchDevice.Click += new System.EventHandler(this.btnSearchDevice_Click);


            // 
            // btnConnectDevice
            // 
            this.btnConnectDevice.Location = new System.Drawing.Point(260, 460);
            this.btnConnectDevice.Name = "btnConnectDevice";
            this.btnConnectDevice.Size = new System.Drawing.Size(100, 29);
            this.btnConnectDevice.TabIndex = 16;
            this.btnConnectDevice.Text = "CONNECT";
            this.btnConnectDevice.UseVisualStyleBackColor = true;
            this.btnConnectDevice.Click += new System.EventHandler(this.btnConnectDevice_Click);

            // 
            // lblDeviceStatus
            // 
            this.lblDeviceStatus.AutoSize = true;
            this.lblDeviceStatus.Location = new System.Drawing.Point(10, 510);
            this.lblDeviceStatus.Name = "lblDeviceStatus";
            this.lblDeviceStatus.Size = new System.Drawing.Size(180, 13);
            this.lblDeviceStatus.TabIndex = 17;
            this.lblDeviceStatus.Text = "COM Status : Recording ●";

            // 
            // btnStartTreatment
            // 
            this.btnStartTreatment.Enabled = false;
            this.btnStartTreatment.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold);
            this.btnStartTreatment.Location = new System.Drawing.Point(250, 570);
            this.btnStartTreatment.Name = "btnStartTreatment";
            this.btnStartTreatment.Size = new System.Drawing.Size(160, 40);
            this.btnStartTreatment.TabIndex = 18;
            this.btnStartTreatment.Text = "Start";
            this.btnStartTreatment.UseVisualStyleBackColor = true;
            this.btnStartTreatment.Click += new System.EventHandler(this.btnStartTreatment_Click);

            // 
            // ConnectDeviceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1520, 860);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.panelLeft);
            this.Controls.Add(this.panelRight);
            this.Name = "ConnectDeviceForm";
            this.Text = "Connect Device";
            this.panelLeft.ResumeLayout(false);
            this.panelLeft.PerformLayout();
            this.panelPatientInfo.ResumeLayout(false);
            this.panelPatientInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
            this.panelDetails.ResumeLayout(false);
            this.panelDetails.PerformLayout();
            this.panelRecentVisits.ResumeLayout(false);
            this.panelRecentVisits.PerformLayout();
            this.panelRight.ResumeLayout(false);
            this.panelRight.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panelLeft;
        private System.Windows.Forms.Label lblPatientDetails;
        private System.Windows.Forms.Panel panelPatientInfo;
        private System.Windows.Forms.PictureBox picAvatar;
        private System.Windows.Forms.Label lblPatientName;
        private System.Windows.Forms.Label lblPatientId;
        private System.Windows.Forms.Panel panelDetails;
        private System.Windows.Forms.Label lblAgeLabel;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblGenderLabel;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBloodTypeLabel;
        private System.Windows.Forms.Label lblBloodType;
        private System.Windows.Forms.Label lblHeightLabel;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeightLabel;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Panel panelRecentVisits;
        private System.Windows.Forms.Label lblRecentVisits;
        private System.Windows.Forms.Label lblSelectedPart;
        private System.Windows.Forms.Label lblSelectedDate;
        private System.Windows.Forms.Label lblExposureTime;
        private System.Windows.Forms.ComboBox cmbExposureTime;
        private System.Windows.Forms.TextBox txtCustomTime;
        private System.Windows.Forms.Label lblCustomMinutes;
        private System.Windows.Forms.Label lblCurrentSetting;
        private System.Windows.Forms.Panel panelRight;
        private System.Windows.Forms.Label lblWaveform;
        private System.Windows.Forms.Label lblCZ;
        private System.Windows.Forms.Panel panelChartCZ;
        private System.Windows.Forms.Label lblMaxCZ;
        private System.Windows.Forms.TextBox txtMaxCZ;
        private System.Windows.Forms.Label lblMinCZ;
        private System.Windows.Forms.TextBox txtMinCZ;
        private System.Windows.Forms.Label lblFZ;
        private System.Windows.Forms.Panel panelChartFZ;
        private System.Windows.Forms.Label lblMaxFZ;
        private System.Windows.Forms.TextBox txtMaxFZ;
        private System.Windows.Forms.Label lblMinFZ;
        private System.Windows.Forms.TextBox txtMinFZ;
        private System.Windows.Forms.Button btnUpdateRange;
        private System.Windows.Forms.ComboBox cmbComport;
        private System.Windows.Forms.Button btnSearchDevice;
        private System.Windows.Forms.Button btnConnectDevice;
        private System.Windows.Forms.Label lblDeviceStatus;
        private System.Windows.Forms.Button btnStartTreatment;
        private System.Windows.Forms.Button btnBack;
    }
}