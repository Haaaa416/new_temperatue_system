﻿using System;

namespace NFT_BLE_expert_
{
    public class PatientData
    {
        public string Id { get; set; }           // e.g. PAT-2025-5244
        public string Name { get; set; }
        public DateTime Dob { get; set; }
        public string Gender { get; set; }       // Male/Female/Other
        public string BloodType { get; set; }    // A/B/O/AB
        public int HeightCm { get; set; }
        public int WeightKg { get; set; }
        public string AvatarPath { get; set; }

        public int Age => CalcAge(Dob, DateTime.Today);

        public static int CalcAge(DateTime dob, DateTime today)
        {
            int age = today.Year - dob.Year;
            if (dob.Date > today.AddYears(-age)) age--;
            return Math.Max(age, 0);
        }
    }
}
