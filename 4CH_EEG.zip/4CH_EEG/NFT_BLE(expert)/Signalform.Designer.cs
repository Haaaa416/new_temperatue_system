﻿namespace NFT_BLE_expert_
{
    partial class Signalform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.frequency_chart = new LiveCharts.WinForms.CartesianChart();
            this.label_CH4 = new MaterialSkin.Controls.MaterialLabel();
            this.label_CH3 = new MaterialSkin.Controls.MaterialLabel();
            this.label_CH2 = new MaterialSkin.Controls.MaterialLabel();
            this.label_CH1 = new MaterialSkin.Controls.MaterialLabel();
            this.label_FileStatus = new MaterialSkin.Controls.MaterialLabel();
            this.comboBox_Comport = new System.Windows.Forms.ComboBox();
            this.BTN_Stop = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BTN_Start = new MaterialSkin.Controls.MaterialRaisedButton();
            this.BTN_Connect = new MaterialSkin.Controls.MaterialRaisedButton();
            this.panel_CH4 = new System.Windows.Forms.Panel();
            this.panel_CH3 = new System.Windows.Forms.Panel();
            this.panel_CH2 = new System.Windows.Forms.Panel();
            this.label_status = new MaterialSkin.Controls.MaterialLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Button_Set = new MaterialSkin.Controls.MaterialRaisedButton();
            this.signal_min = new System.Windows.Forms.TextBox();
            this.signal_max = new System.Windows.Forms.TextBox();
            this.label_min = new MaterialSkin.Controls.MaterialLabel();
            this.label_max = new MaterialSkin.Controls.MaterialLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.materialRaisedButton1 = new MaterialSkin.Controls.MaterialRaisedButton();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel6 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            this.materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            this.signal4_min = new System.Windows.Forms.TextBox();
            this.signal4_max = new System.Windows.Forms.TextBox();
            this.signal3_min = new System.Windows.Forms.TextBox();
            this.signal3_max = new System.Windows.Forms.TextBox();
            this.signal2_min = new System.Windows.Forms.TextBox();
            this.signal2_max = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.BTN_search = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_search)).BeginInit();
            this.SuspendLayout();
            // 
            // frequency_chart
            // 
            this.frequency_chart.Location = new System.Drawing.Point(67, 750);
            this.frequency_chart.Margin = new System.Windows.Forms.Padding(4);
            this.frequency_chart.Name = "frequency_chart";
            this.frequency_chart.Size = new System.Drawing.Size(440, 146);
            this.frequency_chart.TabIndex = 9;
            this.frequency_chart.Text = "cartesianChart2";
            // 
            // label_CH4
            // 
            this.label_CH4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_CH4.AutoSize = true;
            this.label_CH4.Depth = 0;
            this.label_CH4.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_CH4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_CH4.Location = new System.Drawing.Point(1696, 564);
            this.label_CH4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CH4.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_CH4.Name = "label_CH4";
            this.label_CH4.Size = new System.Drawing.Size(43, 24);
            this.label_CH4.TabIndex = 33;
            this.label_CH4.Text = "Fp1";
            // 
            // label_CH3
            // 
            this.label_CH3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_CH3.AutoSize = true;
            this.label_CH3.Depth = 0;
            this.label_CH3.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_CH3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_CH3.Location = new System.Drawing.Point(1703, 381);
            this.label_CH3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CH3.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_CH3.Name = "label_CH3";
            this.label_CH3.Size = new System.Drawing.Size(43, 24);
            this.label_CH3.TabIndex = 32;
            this.label_CH3.Text = "Fp2";
            // 
            // label_CH2
            // 
            this.label_CH2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_CH2.AutoSize = true;
            this.label_CH2.Depth = 0;
            this.label_CH2.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_CH2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_CH2.Location = new System.Drawing.Point(1700, 214);
            this.label_CH2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CH2.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_CH2.Name = "label_CH2";
            this.label_CH2.Size = new System.Drawing.Size(33, 24);
            this.label_CH2.TabIndex = 31;
            this.label_CH2.Text = "C4";
            // 
            // label_CH1
            // 
            this.label_CH1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_CH1.AutoSize = true;
            this.label_CH1.Depth = 0;
            this.label_CH1.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_CH1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_CH1.Location = new System.Drawing.Point(1704, 35);
            this.label_CH1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_CH1.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_CH1.Name = "label_CH1";
            this.label_CH1.Size = new System.Drawing.Size(33, 24);
            this.label_CH1.TabIndex = 30;
            this.label_CH1.Text = "C3";
            // 
            // label_FileStatus
            // 
            this.label_FileStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_FileStatus.AutoSize = true;
            this.label_FileStatus.Depth = 0;
            this.label_FileStatus.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_FileStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_FileStatus.Location = new System.Drawing.Point(1499, 872);
            this.label_FileStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_FileStatus.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_FileStatus.Name = "label_FileStatus";
            this.label_FileStatus.Size = new System.Drawing.Size(104, 24);
            this.label_FileStatus.TabIndex = 27;
            this.label_FileStatus.Text = "[FileStatus]";
            // 
            // comboBox_Comport
            // 
            this.comboBox_Comport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.comboBox_Comport.FormattingEnabled = true;
            this.comboBox_Comport.Location = new System.Drawing.Point(1263, 774);
            this.comboBox_Comport.Margin = new System.Windows.Forms.Padding(4);
            this.comboBox_Comport.Name = "comboBox_Comport";
            this.comboBox_Comport.Size = new System.Drawing.Size(156, 23);
            this.comboBox_Comport.TabIndex = 25;
            // 
            // BTN_Stop
            // 
            this.BTN_Stop.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_Stop.Depth = 0;
            this.BTN_Stop.Location = new System.Drawing.Point(1636, 825);
            this.BTN_Stop.Margin = new System.Windows.Forms.Padding(4);
            this.BTN_Stop.MouseState = MaterialSkin.MouseState.HOVER;
            this.BTN_Stop.Name = "BTN_Stop";
            this.BTN_Stop.Primary = true;
            this.BTN_Stop.Size = new System.Drawing.Size(100, 29);
            this.BTN_Stop.TabIndex = 24;
            this.BTN_Stop.Text = "Stop";
            this.BTN_Stop.UseVisualStyleBackColor = true;
            this.BTN_Stop.Click += new System.EventHandler(this.BTN_Stop_Click);
            // 
            // BTN_Start
            // 
            this.BTN_Start.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_Start.Depth = 0;
            this.BTN_Start.Location = new System.Drawing.Point(1528, 825);
            this.BTN_Start.Margin = new System.Windows.Forms.Padding(4);
            this.BTN_Start.MouseState = MaterialSkin.MouseState.HOVER;
            this.BTN_Start.Name = "BTN_Start";
            this.BTN_Start.Primary = true;
            this.BTN_Start.Size = new System.Drawing.Size(100, 29);
            this.BTN_Start.TabIndex = 23;
            this.BTN_Start.Text = "Start";
            this.BTN_Start.UseVisualStyleBackColor = true;
            this.BTN_Start.Click += new System.EventHandler(this.materialRaisedButton1_Click);
            // 
            // BTN_Connect
            // 
            this.BTN_Connect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_Connect.Depth = 0;
            this.BTN_Connect.Location = new System.Drawing.Point(1304, 825);
            this.BTN_Connect.Margin = new System.Windows.Forms.Padding(4);
            this.BTN_Connect.MouseState = MaterialSkin.MouseState.HOVER;
            this.BTN_Connect.Name = "BTN_Connect";
            this.BTN_Connect.Primary = true;
            this.BTN_Connect.Size = new System.Drawing.Size(100, 29);
            this.BTN_Connect.TabIndex = 22;
            this.BTN_Connect.Text = "Connect";
            this.BTN_Connect.UseVisualStyleBackColor = true;
            this.BTN_Connect.Click += new System.EventHandler(this.BTN_Connect_Click);
            // 
            // panel_CH4
            // 
            this.panel_CH4.AutoSize = true;
            this.panel_CH4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_CH4.Location = new System.Drawing.Point(4, 529);
            this.panel_CH4.Margin = new System.Windows.Forms.Padding(4);
            this.panel_CH4.Name = "panel_CH4";
            this.panel_CH4.Size = new System.Drawing.Size(1591, 167);
            this.panel_CH4.TabIndex = 21;
            // 
            // panel_CH3
            // 
            this.panel_CH3.AutoSize = true;
            this.panel_CH3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_CH3.Location = new System.Drawing.Point(4, 354);
            this.panel_CH3.Margin = new System.Windows.Forms.Padding(4);
            this.panel_CH3.Name = "panel_CH3";
            this.panel_CH3.Size = new System.Drawing.Size(1591, 167);
            this.panel_CH3.TabIndex = 21;
            // 
            // panel_CH2
            // 
            this.panel_CH2.AutoSize = true;
            this.panel_CH2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_CH2.Location = new System.Drawing.Point(4, 179);
            this.panel_CH2.Margin = new System.Windows.Forms.Padding(4);
            this.panel_CH2.Name = "panel_CH2";
            this.panel_CH2.Size = new System.Drawing.Size(1591, 167);
            this.panel_CH2.TabIndex = 21;
            // 
            // label_status
            // 
            this.label_status.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label_status.AutoSize = true;
            this.label_status.Depth = 0;
            this.label_status.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_status.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_status.Location = new System.Drawing.Point(1499, 775);
            this.label_status.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_status.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_status.Name = "label_status";
            this.label_status.Size = new System.Drawing.Size(115, 24);
            this.label_status.TabIndex = 21;
            this.label_status.Text = "COM Status:";
            // 
            // panel2
            // 
            this.panel2.AutoSize = true;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1591, 167);
            this.panel2.TabIndex = 20;
            // 
            // Button_Set
            // 
            this.Button_Set.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.Button_Set.Depth = 0;
            this.Button_Set.Location = new System.Drawing.Point(1687, 710);
            this.Button_Set.Margin = new System.Windows.Forms.Padding(4);
            this.Button_Set.MouseState = MaterialSkin.MouseState.HOVER;
            this.Button_Set.Name = "Button_Set";
            this.Button_Set.Primary = true;
            this.Button_Set.Size = new System.Drawing.Size(100, 29);
            this.Button_Set.TabIndex = 17;
            this.Button_Set.Text = "Setting";
            this.Button_Set.UseVisualStyleBackColor = true;
            this.Button_Set.Click += new System.EventHandler(this.Button_Set_Click);
            // 
            // signal_min
            // 
            this.signal_min.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal_min.Location = new System.Drawing.Point(1664, 150);
            this.signal_min.Margin = new System.Windows.Forms.Padding(4);
            this.signal_min.Name = "signal_min";
            this.signal_min.Size = new System.Drawing.Size(124, 25);
            this.signal_min.TabIndex = 19;
            // 
            // signal_max
            // 
            this.signal_max.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal_max.Location = new System.Drawing.Point(1661, 88);
            this.signal_max.Margin = new System.Windows.Forms.Padding(4);
            this.signal_max.Name = "signal_max";
            this.signal_max.Size = new System.Drawing.Size(124, 25);
            this.signal_max.TabIndex = 18;
            // 
            // label_min
            // 
            this.label_min.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_min.AutoSize = true;
            this.label_min.Depth = 0;
            this.label_min.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_min.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_min.Location = new System.Drawing.Point(1704, 120);
            this.label_min.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_min.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_min.Name = "label_min";
            this.label_min.Size = new System.Drawing.Size(42, 24);
            this.label_min.TabIndex = 17;
            this.label_min.Text = "Min";
            // 
            // label_max
            // 
            this.label_max.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_max.AutoSize = true;
            this.label_max.Depth = 0;
            this.label_max.Font = new System.Drawing.Font("Roboto", 11F);
            this.label_max.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label_max.Location = new System.Drawing.Point(1703, 59);
            this.label_max.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_max.MouseState = MaterialSkin.MouseState.HOVER;
            this.label_max.Name = "label_max";
            this.label_max.Size = new System.Drawing.Size(46, 24);
            this.label_max.TabIndex = 16;
            this.label_max.Text = "Max";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoSize = true;
            this.panel1.Controls.Add(this.materialRaisedButton1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.materialLabel5);
            this.panel1.Controls.Add(this.materialLabel6);
            this.panel1.Controls.Add(this.materialLabel3);
            this.panel1.Controls.Add(this.materialLabel4);
            this.panel1.Controls.Add(this.materialLabel1);
            this.panel1.Controls.Add(this.materialLabel2);
            this.panel1.Controls.Add(this.signal4_min);
            this.panel1.Controls.Add(this.signal4_max);
            this.panel1.Controls.Add(this.signal3_min);
            this.panel1.Controls.Add(this.signal3_max);
            this.panel1.Controls.Add(this.signal2_min);
            this.panel1.Controls.Add(this.signal2_max);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.label_CH4);
            this.panel1.Controls.Add(this.label_CH3);
            this.panel1.Controls.Add(this.frequency_chart);
            this.panel1.Controls.Add(this.label_CH2);
            this.panel1.Controls.Add(this.label_CH1);
            this.panel1.Controls.Add(this.label_FileStatus);
            this.panel1.Controls.Add(this.BTN_search);
            this.panel1.Controls.Add(this.comboBox_Comport);
            this.panel1.Controls.Add(this.BTN_Stop);
            this.panel1.Controls.Add(this.BTN_Start);
            this.panel1.Controls.Add(this.BTN_Connect);
            this.panel1.Controls.Add(this.label_status);
            this.panel1.Controls.Add(this.Button_Set);
            this.panel1.Controls.Add(this.signal_min);
            this.panel1.Controls.Add(this.signal_max);
            this.panel1.Controls.Add(this.label_min);
            this.panel1.Controls.Add(this.label_max);
            this.panel1.Location = new System.Drawing.Point(16, 90);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1809, 930);
            this.panel1.TabIndex = 16;
            // 
            // materialRaisedButton1
            // 
            this.materialRaisedButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.materialRaisedButton1.Depth = 0;
            this.materialRaisedButton1.Location = new System.Drawing.Point(1420, 825);
            this.materialRaisedButton1.Margin = new System.Windows.Forms.Padding(4);
            this.materialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialRaisedButton1.Name = "materialRaisedButton1";
            this.materialRaisedButton1.Primary = true;
            this.materialRaisedButton1.Size = new System.Drawing.Size(100, 29);
            this.materialRaisedButton1.TabIndex = 50;
            this.materialRaisedButton1.Text = "baseline";
            this.materialRaisedButton1.UseVisualStyleBackColor = true;
            this.materialRaisedButton1.Click += new System.EventHandler(this.materialRaisedButton1_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1260, 872);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 15);
            this.label1.TabIndex = 49;
            this.label1.Text = "訓練時間：";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(1355, 869);
            this.textBox1.Margin = new System.Windows.Forms.Padding(4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(107, 25);
            this.textBox1.TabIndex = 48;
            this.textBox1.Text = "360";
            // 
            // materialLabel5
            // 
            this.materialLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel5.AutoSize = true;
            this.materialLabel5.Depth = 0;
            this.materialLabel5.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel5.Location = new System.Drawing.Point(1700, 648);
            this.materialLabel5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel5.Name = "materialLabel5";
            this.materialLabel5.Size = new System.Drawing.Size(42, 24);
            this.materialLabel5.TabIndex = 47;
            this.materialLabel5.Text = "Min";
            // 
            // materialLabel6
            // 
            this.materialLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel6.AutoSize = true;
            this.materialLabel6.Depth = 0;
            this.materialLabel6.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel6.Location = new System.Drawing.Point(1700, 588);
            this.materialLabel6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel6.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel6.Name = "materialLabel6";
            this.materialLabel6.Size = new System.Drawing.Size(46, 24);
            this.materialLabel6.TabIndex = 46;
            this.materialLabel6.Text = "Max";
            // 
            // materialLabel3
            // 
            this.materialLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel3.AutoSize = true;
            this.materialLabel3.Depth = 0;
            this.materialLabel3.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel3.Location = new System.Drawing.Point(1703, 472);
            this.materialLabel3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel3.Name = "materialLabel3";
            this.materialLabel3.Size = new System.Drawing.Size(42, 24);
            this.materialLabel3.TabIndex = 45;
            this.materialLabel3.Text = "Min";
            this.materialLabel3.Click += new System.EventHandler(this.materialLabel3_Click);
            // 
            // materialLabel4
            // 
            this.materialLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel4.AutoSize = true;
            this.materialLabel4.Depth = 0;
            this.materialLabel4.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel4.Location = new System.Drawing.Point(1707, 411);
            this.materialLabel4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel4.Name = "materialLabel4";
            this.materialLabel4.Size = new System.Drawing.Size(46, 24);
            this.materialLabel4.TabIndex = 44;
            this.materialLabel4.Text = "Max";
            this.materialLabel4.Click += new System.EventHandler(this.materialLabel4_Click);
            // 
            // materialLabel1
            // 
            this.materialLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel1.AutoSize = true;
            this.materialLabel1.Depth = 0;
            this.materialLabel1.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel1.Location = new System.Drawing.Point(1700, 296);
            this.materialLabel1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel1.Name = "materialLabel1";
            this.materialLabel1.Size = new System.Drawing.Size(42, 24);
            this.materialLabel1.TabIndex = 43;
            this.materialLabel1.Text = "Min";
            // 
            // materialLabel2
            // 
            this.materialLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.materialLabel2.AutoSize = true;
            this.materialLabel2.Depth = 0;
            this.materialLabel2.Font = new System.Drawing.Font("Roboto", 11F);
            this.materialLabel2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.materialLabel2.Location = new System.Drawing.Point(1700, 238);
            this.materialLabel2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            this.materialLabel2.Name = "materialLabel2";
            this.materialLabel2.Size = new System.Drawing.Size(46, 24);
            this.materialLabel2.TabIndex = 42;
            this.materialLabel2.Text = "Max";
            // 
            // signal4_min
            // 
            this.signal4_min.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal4_min.Location = new System.Drawing.Point(1661, 675);
            this.signal4_min.Margin = new System.Windows.Forms.Padding(4);
            this.signal4_min.Name = "signal4_min";
            this.signal4_min.Size = new System.Drawing.Size(124, 25);
            this.signal4_min.TabIndex = 41;
            // 
            // signal4_max
            // 
            this.signal4_max.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal4_max.Location = new System.Drawing.Point(1661, 615);
            this.signal4_max.Margin = new System.Windows.Forms.Padding(4);
            this.signal4_max.Name = "signal4_max";
            this.signal4_max.Size = new System.Drawing.Size(124, 25);
            this.signal4_max.TabIndex = 40;
            // 
            // signal3_min
            // 
            this.signal3_min.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal3_min.Location = new System.Drawing.Point(1663, 500);
            this.signal3_min.Margin = new System.Windows.Forms.Padding(4);
            this.signal3_min.Name = "signal3_min";
            this.signal3_min.Size = new System.Drawing.Size(124, 25);
            this.signal3_min.TabIndex = 39;
            // 
            // signal3_max
            // 
            this.signal3_max.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal3_max.Location = new System.Drawing.Point(1663, 441);
            this.signal3_max.Margin = new System.Windows.Forms.Padding(4);
            this.signal3_max.Name = "signal3_max";
            this.signal3_max.Size = new System.Drawing.Size(124, 25);
            this.signal3_max.TabIndex = 38;
            // 
            // signal2_min
            // 
            this.signal2_min.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal2_min.Location = new System.Drawing.Point(1664, 326);
            this.signal2_min.Margin = new System.Windows.Forms.Padding(4);
            this.signal2_min.Name = "signal2_min";
            this.signal2_min.Size = new System.Drawing.Size(124, 25);
            this.signal2_min.TabIndex = 37;
            // 
            // signal2_max
            // 
            this.signal2_max.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.signal2_max.Location = new System.Drawing.Point(1664, 265);
            this.signal2_max.Margin = new System.Windows.Forms.Padding(4);
            this.signal2_max.Name = "signal2_max";
            this.signal2_max.Size = new System.Drawing.Size(124, 25);
            this.signal2_max.TabIndex = 36;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panel_CH4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel_CH3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel_CH2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(33, 28);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1599, 700);
            this.tableLayoutPanel1.TabIndex = 35;
            // 
            // BTN_search
            // 
            this.BTN_search.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BTN_search.Image = global::NFT_BLE_expert_.Properties.Resources.comfresh;
            this.BTN_search.Location = new System.Drawing.Point(1428, 774);
            this.BTN_search.Margin = new System.Windows.Forms.Padding(4);
            this.BTN_search.Name = "BTN_search";
            this.BTN_search.Size = new System.Drawing.Size(35, 25);
            this.BTN_search.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.BTN_search.TabIndex = 26;
            this.BTN_search.TabStop = false;
            this.BTN_search.Click += new System.EventHandler(this.BTN_search_Click);
            // 
            // Signalform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1839, 1035);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Signalform";
            this.Text = "Signalform";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Signalform_FormClosed);
            this.Load += new System.EventHandler(this.Signalform_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_search)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private LiveCharts.WinForms.CartesianChart frequency_chart;
        private System.Windows.Forms.TextBox signal_min;
        private System.Windows.Forms.TextBox signal_max;
        private MaterialSkin.Controls.MaterialLabel label_min;
        private MaterialSkin.Controls.MaterialLabel label_max;
        private MaterialSkin.Controls.MaterialRaisedButton Button_Set;
        private System.Windows.Forms.Panel panel2;
        private MaterialSkin.Controls.MaterialLabel label_status;
        private System.Windows.Forms.Panel panel_CH4;
        private System.Windows.Forms.Panel panel_CH3;
        private System.Windows.Forms.Panel panel_CH2;
        private MaterialSkin.Controls.MaterialRaisedButton BTN_Start;
        private MaterialSkin.Controls.MaterialRaisedButton BTN_Connect;
        private System.Windows.Forms.ComboBox comboBox_Comport;
        private MaterialSkin.Controls.MaterialRaisedButton BTN_Stop;
        private System.Windows.Forms.PictureBox BTN_search;
        private MaterialSkin.Controls.MaterialLabel label_FileStatus;
        private MaterialSkin.Controls.MaterialLabel label_CH4;
        private MaterialSkin.Controls.MaterialLabel label_CH3;
        private MaterialSkin.Controls.MaterialLabel label_CH2;
        private MaterialSkin.Controls.MaterialLabel label_CH1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox signal4_min;
        private System.Windows.Forms.TextBox signal4_max;
        private System.Windows.Forms.TextBox signal3_min;
        private System.Windows.Forms.TextBox signal3_max;
        private System.Windows.Forms.TextBox signal2_min;
        private System.Windows.Forms.TextBox signal2_max;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialLabel materialLabel6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
        private MaterialSkin.Controls.MaterialRaisedButton materialRaisedButton1;
    }
}