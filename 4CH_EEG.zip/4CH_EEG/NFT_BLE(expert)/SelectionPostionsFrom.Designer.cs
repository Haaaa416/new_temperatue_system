﻿namespace NFT_BLE_expert_
{
    partial class SelectionPositionsFrom
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel leftPanel;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblPatientDetailsTitle;
        private System.Windows.Forms.PictureBox picAvatar;
        private System.Windows.Forms.Label lblPatientName;
        private System.Windows.Forms.Label lblPatientId;
        private System.Windows.Forms.Label lblAgeLabel;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblGenderLabel;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBloodTypeLabel;
        private System.Windows.Forms.Label lblBloodType;
        private System.Windows.Forms.Label lblHeightLabel;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeightLabel;
        private System.Windows.Forms.Label lblWeight;
        private System.Windows.Forms.Label lblRecentVisits;
        private System.Windows.Forms.ListBox lstVisits;
        private System.Windows.Forms.Label lblBodyVisualization;
        private System.Windows.Forms.Panel visualizationPanel;
        private System.Windows.Forms.Label lblFront;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.PictureBox picFront;
        private System.Windows.Forms.PictureBox picBack;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnBack;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.leftPanel = new System.Windows.Forms.Panel();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblPatientDetailsTitle = new System.Windows.Forms.Label();
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.lblPatientName = new System.Windows.Forms.Label();
            this.lblPatientId = new System.Windows.Forms.Label();
            this.lblAgeLabel = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblGenderLabel = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblBloodTypeLabel = new System.Windows.Forms.Label();
            this.lblBloodType = new System.Windows.Forms.Label();
            this.lblHeightLabel = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblWeightLabel = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();
            this.lblRecentVisits = new System.Windows.Forms.Label();
            this.lstVisits = new System.Windows.Forms.ListBox();
            this.lblBodyVisualization = new System.Windows.Forms.Label();
            this.visualizationPanel = new System.Windows.Forms.Panel();
            this.lblFront = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.picFront = new System.Windows.Forms.PictureBox();
            this.picBack = new System.Windows.Forms.PictureBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();

            this.leftPanel.SuspendLayout();
            this.rightPanel.SuspendLayout();
            this.visualizationPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFront)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBack)).BeginInit();
            this.SuspendLayout();

            // 
            // Form
            // 
            this.ClientSize = new System.Drawing.Size(1400, 800);
            this.BackColor = System.Drawing.Color.FromArgb(247, 247, 251);
            this.Name = "SelectionPositionsFrom";
            this.Text = "Selection Positions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = false;
            this.lblTitle.Text = "BATC";
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(30, 15);
            this.lblTitle.Size = new System.Drawing.Size(200, 40);
            this.Controls.Add(this.lblTitle);

            // 
            // btnBack (Top)
            // 
            this.btnBack.Text = "← Back";
            this.btnBack.Location = new System.Drawing.Point(150, 20);
            this.btnBack.Size = new System.Drawing.Size(100, 35);
            this.btnBack.BackColor = System.Drawing.Color.White;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(209, 209, 209);
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            this.Controls.Add(this.btnBack);

            // 
            // leftPanel
            // 
            this.leftPanel.Location = new System.Drawing.Point(30, 80);
            this.leftPanel.Size = new System.Drawing.Size(360, 680);
            this.leftPanel.BackColor = System.Drawing.Color.White;
            this.leftPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // 
            // lblPatientDetailsTitle
            // 
            this.lblPatientDetailsTitle.Text = "Patient Details";
            this.lblPatientDetailsTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblPatientDetailsTitle.Location = new System.Drawing.Point(20, 15);
            this.lblPatientDetailsTitle.Size = new System.Drawing.Size(320, 30);
            this.leftPanel.Controls.Add(this.lblPatientDetailsTitle);

            // 
            // picAvatar
            // 
            this.picAvatar.Location = new System.Drawing.Point(20, 60);
            this.picAvatar.Size = new System.Drawing.Size(52, 52);
            this.picAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picAvatar.BackColor = System.Drawing.Color.FromArgb(243, 244, 246);
            this.picAvatar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.leftPanel.Controls.Add(this.picAvatar);

            // 
            // lblPatientName
            // 
            this.lblPatientName.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblPatientName.Location = new System.Drawing.Point(85, 63);
            this.lblPatientName.Size = new System.Drawing.Size(250, 22);
            this.leftPanel.Controls.Add(this.lblPatientName);

            // 
            // lblPatientId
            // 
            this.lblPatientId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblPatientId.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblPatientId.Location = new System.Drawing.Point(85, 88);
            this.lblPatientId.Size = new System.Drawing.Size(250, 20);
            this.leftPanel.Controls.Add(this.lblPatientId);

            // 新增一條分隔線
            var separator1 = new System.Windows.Forms.Panel();
            separator1.Location = new System.Drawing.Point(20, 125);
            separator1.Size = new System.Drawing.Size(320, 2);
            separator1.BackColor = System.Drawing.Color.FromArgb(209, 209, 209);
            this.leftPanel.Controls.Add(separator1);

            int yPos = 145;
            int spacing = 32;

            // Age
            this.lblAgeLabel = CreateDetailLabel("Age", 30, yPos);
            this.lblAge = CreateDetailValue("", 280, yPos);
            this.leftPanel.Controls.Add(this.lblAgeLabel);
            this.leftPanel.Controls.Add(this.lblAge);
            yPos += spacing;

            // Gender
            this.lblGenderLabel = CreateDetailLabel("Gender", 30, yPos);
            this.lblGender = CreateDetailValue("", 280, yPos);
            this.leftPanel.Controls.Add(this.lblGenderLabel);
            this.leftPanel.Controls.Add(this.lblGender);
            yPos += spacing;

            // Blood Type
            this.lblBloodTypeLabel = CreateDetailLabel("Blood Type", 30, yPos);
            this.lblBloodType = CreateDetailValue("", 280, yPos);
            this.leftPanel.Controls.Add(this.lblBloodTypeLabel);
            this.leftPanel.Controls.Add(this.lblBloodType);
            yPos += spacing;

            // Height
            this.lblHeightLabel = CreateDetailLabel("Height(cm)", 30, yPos);
            this.lblHeight = CreateDetailValue("", 280, yPos);
            this.leftPanel.Controls.Add(this.lblHeightLabel);
            this.leftPanel.Controls.Add(this.lblHeight);
            yPos += spacing;

            // Weight
            this.lblWeightLabel = CreateDetailLabel("Weight(kg)", 30, yPos);
            this.lblWeight = CreateDetailValue("", 280, yPos);
            this.leftPanel.Controls.Add(this.lblWeightLabel);
            this.leftPanel.Controls.Add(this.lblWeight);

            // 新增一條分隔線
            var separator2 = new System.Windows.Forms.Panel();
            separator2.Location = new System.Drawing.Point(20, 315);
            separator2.Size = new System.Drawing.Size(320, 2);
            separator2.BackColor = System.Drawing.Color.FromArgb(209, 209, 209);
            this.leftPanel.Controls.Add(separator2);

            // 
            // lblRecentVisits
            // 
            this.lblRecentVisits.Text = "Recent Visits";
            this.lblRecentVisits.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblRecentVisits.Location = new System.Drawing.Point(20, 335);
            this.lblRecentVisits.Size = new System.Drawing.Size(320, 28);
            this.leftPanel.Controls.Add(this.lblRecentVisits);

            // 
            // lstVisits
            // 
            this.lstVisits.Location = new System.Drawing.Point(20, 370);
            this.lstVisits.Size = new System.Drawing.Size(320, 285);
            this.lstVisits.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lstVisits.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lstVisits.BackColor = System.Drawing.Color.White;
            this.lstVisits.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.leftPanel.Controls.Add(this.lstVisits);

            this.Controls.Add(this.leftPanel);

            // 
            // rightPanel
            // 
            this.rightPanel.Location = new System.Drawing.Point(410, 80);
            this.rightPanel.Size = new System.Drawing.Size(960, 680);
            this.rightPanel.BackColor = System.Drawing.Color.White;
            this.rightPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // 
            // lblBodyVisualization
            // 
            this.lblBodyVisualization.Text = "Body Visualization";
            this.lblBodyVisualization.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblBodyVisualization.Location = new System.Drawing.Point(20, 15);
            this.lblBodyVisualization.Size = new System.Drawing.Size(920, 30);
            this.rightPanel.Controls.Add(this.lblBodyVisualization);

            // 
            // visualizationPanel
            // 
            this.visualizationPanel.Location = new System.Drawing.Point(20, 60);
            this.visualizationPanel.Size = new System.Drawing.Size(920, 540);
            this.visualizationPanel.BackColor = System.Drawing.Color.FromArgb(249, 250, 251);
            this.visualizationPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;

            // 
            // lblFront
            // 
            this.lblFront.Text = "Front";
            this.lblFront.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblFront.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblFront.Location = new System.Drawing.Point(220, 15);
            this.lblFront.Size = new System.Drawing.Size(100, 30);
            this.lblFront.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.visualizationPanel.Controls.Add(this.lblFront);

            // 
            // lblBack
            // 
            this.lblBack.Text = "Back";
            this.lblBack.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblBack.ForeColor = System.Drawing.Color.FromArgb(107, 114, 128);
            this.lblBack.Location = new System.Drawing.Point(620, 15);
            this.lblBack.Size = new System.Drawing.Size(100, 30);
            this.lblBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.visualizationPanel.Controls.Add(this.lblBack);

            // 
            // picFront
            // 
            this.picFront.Location = new System.Drawing.Point(120, 55);
            this.picFront.Name = "picFront";
            this.picFront.Size = new System.Drawing.Size(280, 450);
            this.picFront.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFront.BackColor = System.Drawing.Color.White;
            this.picFront.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picFront.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picFront.Paint += new System.Windows.Forms.PaintEventHandler(this.Canvas_Paint);
            this.visualizationPanel.Controls.Add(this.picFront);

            // 
            // picBack
            // 
            this.picBack.Location = new System.Drawing.Point(520, 55);
            this.picBack.Name = "picBack";
            this.picBack.Size = new System.Drawing.Size(280, 450);
            this.picBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBack.BackColor = System.Drawing.Color.White;
            this.picBack.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picBack.Paint += new System.Windows.Forms.PaintEventHandler(this.Canvas_Paint);
            this.visualizationPanel.Controls.Add(this.picBack);

            this.rightPanel.Controls.Add(this.visualizationPanel);

            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(720, 620);
            this.btnClear.Size = new System.Drawing.Size(100, 40);
            this.btnClear.Text = "Clean";
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnClear.BackColor = System.Drawing.Color.White;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(166, 166, 166);
            this.btnClear.FlatAppearance.BorderSize = 2;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.Enabled = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            this.rightPanel.Controls.Add(this.btnClear);

            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(840, 620);
            this.btnConfirm.Size = new System.Drawing.Size(100, 40);
            this.btnConfirm.Text = "Confirm";
            this.btnConfirm.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnConfirm.BackColor = System.Drawing.Color.White;
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(166, 166, 166);
            this.btnConfirm.FlatAppearance.BorderSize = 2;
            this.btnConfirm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnConfirm.Enabled = false;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            this.rightPanel.Controls.Add(this.btnConfirm);

            this.Controls.Add(this.rightPanel);

            this.leftPanel.ResumeLayout(false);
            this.rightPanel.ResumeLayout(false);
            this.visualizationPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFront)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBack)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.Label CreateDetailLabel(string text, int x, int y)
        {
            var label = new System.Windows.Forms.Label();
            label.Text = text;
            label.Location = new System.Drawing.Point(x, y);
            label.Size = new System.Drawing.Size(150, 25);
            label.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            label.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            return label;
        }

        private System.Windows.Forms.Label CreateDetailValue(string text, int x, int y)
        {
            var label = new System.Windows.Forms.Label();
            label.Text = text;
            label.Location = new System.Drawing.Point(x, y);
            label.Size = new System.Drawing.Size(60, 25);
            label.Font = new System.Drawing.Font("Segoe UI", 10F);
            label.ForeColor = System.Drawing.Color.FromArgb(127, 127, 127);
            label.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            return label;
        }
    }
}