﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NFT_BLE_expert_
{
    public partial class PredictFrom : Form
    {
        public PredictFrom()
        {
            InitializeComponent();
        }
    }
}
