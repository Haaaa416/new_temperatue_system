﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Management;
using System.Linq;

namespace NFT_BLE_expert_
{
    public partial class ConnectDeviceForm : Form
    {
        private readonly PatientsForm.PatientCardData _data;
        private readonly string _selectedBodyPart;
        private const string ImgDir = @"C:\Users\user\4CH_EEG\4CH_EEG\NFT_BLE(expert)\Resources";

        // 設備連接狀態
        private bool isDeviceConnected = false;
        private Timer connectionTimer;
        private Timer timerRealTimeData;
        private string[] Portscom;

        // 波形圖表
        private Chart chartCZ;
        private Chart chartFZ;
        private int pointIndex = 0;
        private const int samplerate = 250;
        private float timeshow = 2.5f;

        public ConnectDeviceForm(PatientsForm.PatientCardData data, string selectedBodyPart)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            _selectedBodyPart = selectedBodyPart ?? "Unknown";

            InitializeComponent();
            LoadPatientInfo();
            LoadBodyPartInfo();
            InitializeCharts();

            // 初始化連接計時器
            connectionTimer = new Timer();
            connectionTimer.Interval = 1000;
            connectionTimer.Tick += ConnectionTimer_Tick;

            // 初始化波形繪圖計時器
            timerRealTimeData = new Timer();
            timerRealTimeData.Enabled = false;
            timerRealTimeData.Interval = 10;
            timerRealTimeData.Tick += TimerRealTimeData_Tick;
        }

        // 初始化波形圖表
        private void InitializeCharts()
        {
            // CZ 波形圖
            chartCZ = CreateChart();
            panelChartCZ.Controls.Add(chartCZ);

            // FZ 波形圖
            chartFZ = CreateChart();
            panelChartFZ.Controls.Add(chartFZ);
        }

        private Chart CreateChart()
        {
            Chart chart = new Chart();
            ChartArea ctArea = new ChartArea();
            Series series = new Series();

            chart.BackColor = Color.FromArgb(243, 223, 193);
            chart.BackGradientStyle = GradientStyle.TopBottom;
            chart.BorderlineColor = Color.FromArgb(181, 64, 1);
            chart.BorderlineDashStyle = ChartDashStyle.Solid;
            chart.BorderlineWidth = 2;
            chart.Dock = DockStyle.Fill;

            ctArea.AxisX.IsLabelAutoFit = false;
            ctArea.AxisX.LabelStyle.Font = new Font("Trebuchet MS", 8.25F, FontStyle.Bold);
            ctArea.AxisX.LineColor = Color.FromArgb(64, 64, 64, 64);
            ctArea.AxisX.MajorGrid.LineColor = Color.FromArgb(64, 64, 64, 64);
            ctArea.AxisX.Title = "Time (s)";

            ctArea.AxisY.IsLabelAutoFit = false;
            ctArea.AxisY.LabelStyle.Font = new Font("Trebuchet MS", 8.25F, FontStyle.Bold);
            ctArea.AxisY.LineColor = Color.FromArgb(64, 64, 64, 64);
            ctArea.AxisY.MajorGrid.LineColor = Color.FromArgb(64, 64, 64, 64);
            ctArea.AxisY.Maximum = 500D;
            ctArea.AxisY.Minimum = -500D;
            ctArea.AxisY.Title = "Voltage (uV)";

            ctArea.BackColor = Color.OldLace;
            ctArea.BackGradientStyle = GradientStyle.TopBottom;
            ctArea.BackSecondaryColor = Color.White;
            ctArea.BorderColor = Color.FromArgb(64, 64, 64, 20);
            ctArea.BorderDashStyle = ChartDashStyle.Solid;
            ctArea.Name = "Default";

            chart.ChartAreas.Add(ctArea);

            series.BorderColor = Color.FromArgb(180, 26, 59, 105);
            series.ChartArea = "Default";
            series.ChartType = SeriesChartType.Line;
            series.Name = "Default";
            chart.Series.Add(series);

            return chart;
        }

        // 載入病人資料
        private void LoadPatientInfo()
        {
            lblPatientName.Text = _data.Name;
            lblPatientId.Text = "ID: " + _data.Id;
            lblAge.Text = _data.Age.ToString();
            lblGender.Text = _data.Gender;
            lblBloodType.Text = _data.Blood;
            lblHeight.Text = _data.Height.ToString();
            lblWeight.Text = _data.Weight.ToString();

            if (!string.IsNullOrWhiteSpace(_data.AvatarPath))
            {
                TryLoad(picAvatar, _data.AvatarPath);
            }
        }

        // 載入選擇的部位資訊
        private void LoadBodyPartInfo()
        {
            lblSelectedPart.Text = _selectedBodyPart;
            lblSelectedDate.Text = DateTime.Today.ToString("yyyy/MM/dd");
        }

        // 輔助方法：安全載入圖片
        private static void TryLoad(PictureBox pb, string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        pb.Image = Image.FromStream(fs);
                    }
                }
            }
            catch { }
        }

        // 搜尋設備
        private void btnSearchDevice_Click(object sender, EventArgs e)
        {
            ComportSearch();
        }

        void ComportSearch()
        {
            cmbComport.Items.Clear();
            using (var searcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
            {
                var ports = searcher.Get().Cast<ManagementBaseObject>().ToList();
                string[] PortsName = new string[ports.Count];
                Portscom = new string[ports.Count];

                for (int i = 0; i < ports.Count; i++)
                {
                    Portscom[i] = ports[i]["DeviceID"] as string;
                    PortsName[i] = ports[i]["Caption"] as string;

                    if (PortsName[i].IndexOf("Silicon Labs CP210x USB to UART Bridge") > -1)
                    {
                        PortsName[i] = "Dongle(" + Portscom[i] + ")";
                    }
                }

                cmbComport.Text = "";
                for (int i = 0; i < ports.Count; i++)
                {
                    cmbComport.Items.Add(PortsName[i]);
                    if (cmbComport.Items.Count > 0)
                    {
                        cmbComport.SelectedIndex = 0;
                    }
                }
            }
        }

        // 連接設備
        private void btnConnectDevice_Click(object sender, EventArgs e)
        {
            if (cmbComport.SelectedIndex < 0)
            {
                MessageBox.Show("請先選擇一個設備！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            lblDeviceStatus.Text = "連接中...";
            lblDeviceStatus.ForeColor = Color.Orange;
            btnConnectDevice.Enabled = false;
            btnSearchDevice.Enabled = false;

            connectionTimer.Start();
        }

        private int connectionProgress = 0;
        private void ConnectionTimer_Tick(object sender, EventArgs e)
        {
            connectionProgress++;
            if (connectionProgress >= 3)
            {
                connectionTimer.Stop();
                connectionProgress = 0;
                isDeviceConnected = true;

                lblDeviceStatus.Text = "COM Status : Recording ●";
                lblDeviceStatus.ForeColor = Color.Green;
                btnConnectDevice.Enabled = false;
                btnStartTreatment.Enabled = true;
                btnSearchDevice.Enabled = false;

                // 開始繪製波形
                timerRealTimeData.Enabled = true;
            }
        }

        // 波形繪製
        private void TimerRealTimeData_Tick(object sender, EventArgs e)
        {
            int numberOfPointsInChart = (int)(samplerate * timeshow);
            int numberOfPointsAfterRemoval = (int)(samplerate * timeshow);

            // 模擬數據
            Random rand = new Random();
            for (int i = 0; i < 10; i++)
            {
                pointIndex++;
                float newYCZ = (float)(rand.NextDouble() * 200 - 100);
                float newYFZ = (float)(rand.NextDouble() * 200 - 100);

                chartCZ.Series[0].Points.AddXY(pointIndex, newYCZ);
                chartFZ.Series[0].Points.AddXY(pointIndex, newYFZ);

                // 調整 X 軸
                chartCZ.ResetAutoValues();
                if (chartCZ.ChartAreas["Default"].AxisX.Maximum < pointIndex)
                {
                    chartCZ.ChartAreas["Default"].AxisX.Maximum = pointIndex;
                }

                chartFZ.ResetAutoValues();
                if (chartFZ.ChartAreas["Default"].AxisX.Maximum < pointIndex)
                {
                    chartFZ.ChartAreas["Default"].AxisX.Maximum = pointIndex;
                }

                // 移除舊數據點
                while (chartCZ.Series[0].Points.Count > numberOfPointsInChart)
                {
                    while (chartCZ.Series[0].Points.Count > numberOfPointsAfterRemoval)
                    {
                        chartCZ.Series[0].Points.RemoveAt(0);
                    }
                    chartCZ.ChartAreas["Default"].AxisX.Minimum = pointIndex - numberOfPointsAfterRemoval;
                    chartCZ.ChartAreas["Default"].AxisX.Maximum = chartCZ.ChartAreas["Default"].AxisX.Minimum + numberOfPointsInChart;
                }

                while (chartFZ.Series[0].Points.Count > numberOfPointsInChart)
                {
                    while (chartFZ.Series[0].Points.Count > numberOfPointsAfterRemoval)
                    {
                        chartFZ.Series[0].Points.RemoveAt(0);
                    }
                    chartFZ.ChartAreas["Default"].AxisX.Minimum = pointIndex - numberOfPointsAfterRemoval;
                    chartFZ.ChartAreas["Default"].AxisX.Maximum = chartFZ.ChartAreas["Default"].AxisX.Minimum + numberOfPointsInChart;
                }

                chartCZ.Invalidate();
                chartFZ.Invalidate();
            }
        }

        // 更新圖表範圍
        private void btnUpdateRange_Click(object sender, EventArgs e)
        {
            try
            {
                double maxCZ = double.Parse(txtMaxCZ.Text);
                double minCZ = double.Parse(txtMinCZ.Text);
                double maxFZ = double.Parse(txtMaxFZ.Text);
                double minFZ = double.Parse(txtMinFZ.Text);

                chartCZ.ChartAreas["Default"].AxisY.Maximum = maxCZ;
                chartCZ.ChartAreas["Default"].AxisY.Minimum = minCZ;
                chartFZ.ChartAreas["Default"].AxisY.Maximum = maxFZ;
                chartFZ.ChartAreas["Default"].AxisY.Minimum = minFZ;
            }
            catch
            {
                MessageBox.Show("請輸入有效的數值", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 開始治療
        private void btnStartTreatment_Click(object sender, EventArgs e)
        {
            if (!isDeviceConnected)
            {
                MessageBox.Show("請先連接設備！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string message = $"開始治療\n\n";
            message += $"病人：{_data.Name}\n";
            message += $"部位：{_selectedBodyPart}\n";
            message += $"時間：{cmbExposureTime.Text}";

            var result = MessageBox.Show(message, "確認開始治療", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            if (result == DialogResult.OK)
            {
                MessageBox.Show("治療已開始！", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (isDeviceConnected)
            {
                var result = MessageBox.Show("設備仍在連接中，確定要離開嗎？", "確認", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.No)
                {
                    return;
                }
            }
            this.Close();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (connectionTimer != null)
            {
                connectionTimer.Stop();
                connectionTimer.Dispose();
            }
            if (timerRealTimeData != null)
            {
                timerRealTimeData.Stop();
                timerRealTimeData.Dispose();
            }
            base.OnFormClosing(e);
        }
    }
}