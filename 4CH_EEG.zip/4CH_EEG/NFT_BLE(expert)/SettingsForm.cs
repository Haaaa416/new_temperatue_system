﻿using System;
using System.Drawing;
using System.IO;
using System.Security.Principal;
using System.Windows.Forms;

namespace NFT_BLE_expert_
{
    public partial class SettingsForm : Form
    {
        // 直接用你給的路徑（可改成相對路徑）
        private const string LogoRelativePath =
            @"C:\Users\user\4CH_EEG\4CH_EEG\NFT_BLE(expert)\Resources\logo.png";

        public SettingsForm()
        {
            InitializeComponent();
            LoadLogoFromFile();
            InitRoleOptions();
            CenterLeftContent(); // 進來先置中一次
        }

        private void LoadLogoFromFile()
        {
            try
            {
                var path = LogoRelativePath;
                if (File.Exists(path))
                {
                    using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        pictureBoxLogo.Image = Image.FromStream(fs);
                    }
                    pictureBoxLogo.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    toolTip1.SetToolTip(pictureBoxLogo, $"找不到圖片：{path}");
                }
            }
            catch (Exception ex)
            {
                toolTip1.SetToolTip(pictureBoxLogo, $"載入圖片錯誤：{ex.Message}");
            }
        }

        private void InitRoleOptions()
        {
            comboRole.Items.Clear();
            comboRole.Items.AddRange(new object[] { "Doctor", "Nurse", "Patient", "Admin" });
            comboRole.SelectedIndex = 0;
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            var id = txtAccount.Text.Trim();
            var role = comboRole.SelectedItem?.ToString() ?? "";

            if (string.IsNullOrWhiteSpace(id))
            {
                MessageBox.Show("請輸入 ID。", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtAccount.Focus();
                return;
            }

            // TODO: 這裡做登入驗證

            var next = new PatientsForm();  // 確保專案內有 PatientsFrom form
            this.Hide();
            next.FormClosed += (s, args) => this.Show();
            next.Show();
        }

        private void linkRegister_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            var reg = new RegisterFrom();   // 確保專案內有 RegisterForm form
            this.Hide();
            reg.FormClosed += (s, args) => this.Show();
            reg.Show();
        }

        // 左側區塊畫漸層背景
        private void panelLeft_Paint(object sender, PaintEventArgs e)
        {
            var rect = panelLeft.ClientRectangle;
            if (rect.Width <= 0 || rect.Height <= 0) return;

            using (var br = new System.Drawing.Drawing2D.LinearGradientBrush(
                rect,
                Color.FromArgb(210, 235, 248), // 上
                Color.FromArgb(185, 220, 240), // 下
                90f))
            {
                e.Graphics.FillRectangle(br, rect);
            }
        }

        // 置中左半的 logo 與「BATC」
        private void panelLeft_Resize(object sender, EventArgs e) => CenterLeftContent();

        private void CenterLeftContent()
        {
            // 讓 logo 置中（略往上 20px）
            pictureBoxLogo.Left = (panelLeft.Width - pictureBoxLogo.Width) / 2;
            pictureBoxLogo.Top = (panelLeft.Height - pictureBoxLogo.Height) / 2 - 20;

            // BATC 在 logo 下方 10px，並置中
            lblBrand.Left = pictureBoxLogo.Left + (pictureBoxLogo.Width - lblBrand.Width) / 2;
            lblBrand.Top = pictureBoxLogo.Bottom + 10;
        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void lblId_Click(object sender, EventArgs e)
        {

        }

        private void txtAccount_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblRole_Click(object sender, EventArgs e)
        {

        }

        private void comboRole_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
