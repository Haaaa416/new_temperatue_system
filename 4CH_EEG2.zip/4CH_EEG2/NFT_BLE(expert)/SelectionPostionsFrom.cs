﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace NFT_BLE_expert_
{
    // 定義 P 結構，儲存點的位置和名稱
    public struct P
    {
        public int X { get; }
        public int Y { get; }
        public string Name { get; }

        public P(int x, int y, string name)
        {
            X = x;
            Y = y;
            Name = name;
        }
    }

    public partial class SelectionPositionsFrom : Form
    {
        private readonly PatientsForm.PatientCardData _data;
        private const string ImgDir = @"C:\Users\user\4CH_EEG\4CH_EEG\NFT_BLE(expert)\Resources";

        // 預設前視與後視點位置
        private static readonly P[] FrontPreset = new[]
        {
            new P(110, 150, "left shoulder"),
            new P(175, 150, "right shoulder"),
            new P(67, 200, "left upper arm"),
            new P(215, 200, "right upper arm"),
            new P(120, 275, "left knee"),
            new P(162, 275, "right knee"),
            new P(113, 315, "left ankle"),
            new P(171, 315, "right ankle"),
        };

        private static readonly P[] BackPreset = new[]
        {
            new P(140, 180, "upper back"),
            new P(140, 230, "mid back"),
        };

        private List<Dot> frontDots = new List<Dot>();
        private List<Dot> backDots = new List<Dot>();
        private List<Visit> visits = new List<Visit>();

        // 選擇鎖定相關
        private bool selectionLocked = false;
        private string selectedKey = null;
        private int? lastVisitIndex = null;
        private string lastVisitLabel = null;

        public SelectionPositionsFrom(PatientsForm.PatientCardData data)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            InitializeComponent();
            LoadPatientInfo();
            LoadBodyImages();

            // 使用 MouseClick 事件
            this.picFront.MouseClick += this.Canvas_Click;
            this.picBack.MouseClick += this.Canvas_Click;

            // 設置 Paint 事件
            this.picFront.Paint += this.Canvas_Paint;
            this.picBack.Paint += this.Canvas_Paint;

            UpdateVisitsList();
        }

        // 載入身體圖片
        private void LoadBodyImages()
        {
            TryLoad(picFront, Path.Combine(ImgDir, "body.png"));
            TryLoad(picBack, Path.Combine(ImgDir, "body.png"));
        }

        // 輔助方法：安全載入圖片
        private static void TryLoad(PictureBox pb, string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        pb.Image = Image.FromStream(fs);
                    }
                }
            }
            catch
            {
                // 載入失敗時保持預設背景色
            }
        }

        // 載入病人資料
        private void LoadPatientInfo()
        {
            lblPatientName.Text = _data.Name;
            lblPatientId.Text = "ID: " + _data.Id;
            lblAge.Text = _data.Age.ToString();
            lblGender.Text = _data.Gender;
            lblBloodType.Text = _data.Blood;
            lblHeight.Text = _data.Height.ToString();
            lblWeight.Text = _data.Weight.ToString();

            // 載入頭像
            if (!string.IsNullOrWhiteSpace(_data.AvatarPath))
            {
                TryLoad(picAvatar, _data.AvatarPath);
            }
        }

        // 更新就診記錄列表
        private void UpdateVisitsList()
        {
            lstVisits.Items.Clear();
            if (visits.Count == 0)
            {
                lstVisits.Items.Add("No records yet");
            }
            else
            {
                foreach (var visit in visits.OrderByDescending(v => v.Date))
                {
                    lstVisits.Items.Add($"{visit.Date:MMM dd, yyyy} – {visit.Label}");
                }
            }
        }

        private string KeyFor(P pt, bool isFront)
        {
            return $"{(isFront ? "F" : "B")}:{pt.X},{pt.Y}";
        }

        // 點擊圖片時，根據點擊位置添加標記
        private void Canvas_Click(object sender, MouseEventArgs e)
        {
            var canvas = sender as PictureBox;
            if (canvas == null) return;

            bool isFront = (canvas.Name == "picFront");
            var presets = isFront ? FrontPreset : BackPreset;

            // 找到最近的預設點
            P? closestPoint = null;
            double minDistance = double.MaxValue;

            foreach (var pt in presets)
            {
                double distance = Math.Sqrt(Math.Pow(e.X - pt.X, 2) + Math.Pow(e.Y - pt.Y, 2));
                if (distance < 20 && distance < minDistance) // 20像素範圍內
                {
                    minDistance = distance;
                    closestPoint = pt;
                }
            }

            if (closestPoint.HasValue)
            {
                var pt = closestPoint.Value;
                var key = KeyFor(pt, isFront);

                // 如果已鎖定且不是同一個點，忽略
                if (selectionLocked && key != selectedKey) return;

                if (!selectionLocked)
                {
                    // 添加到訪問記錄
                    var visit = new Visit { Label = pt.Name, Date = DateTime.Today };
                    visits.Add(visit);
                    lastVisitIndex = visits.Count - 1;
                    lastVisitLabel = pt.Name;

                    selectionLocked = true;
                    selectedKey = key;

                    UpdateVisitsList();

                    // 啟用按鈕
                    btnClear.Enabled = true;
                    btnConfirm.Enabled = true;
                }

                // 取得點擊位置的比例
                var x = e.X / (float)canvas.Width;
                var y = e.Y / (float)canvas.Height;
                var dot = new Dot { X = x, Y = y, Label = pt.Name };

                if (isFront)
                {
                    frontDots.Clear(); // 清除之前的點
                    frontDots.Add(dot);
                }
                else
                {
                    backDots.Clear(); // 清除之前的點
                    backDots.Add(dot);
                }

                // 同時刷新兩個畫布
                picFront.Invalidate();
                picBack.Invalidate();
            }
        }

        // 畫出所有選擇的標記
        private void Canvas_Paint(object sender, PaintEventArgs e)
        {
            var canvas = sender as PictureBox;
            if (canvas == null) return;

            bool isFront = (canvas.Name == "picFront");
            var presets = isFront ? FrontPreset : BackPreset;

            // 設置抗鋸齒
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // 繪製預設的紅點
            using (var redBrush = new SolidBrush(Color.FromArgb(255, 26, 26)))
            using (var blackPen = new Pen(Color.Black, 2))
            {
                foreach (var pt in presets)
                {
                    var key = KeyFor(pt, isFront);

                    // 如果已鎖定且不是選中的點，降低透明度
                    if (selectionLocked && key != selectedKey)
                    {
                        using (var fadedBrush = new SolidBrush(Color.FromArgb(80, 255, 26, 26)))
                        using (var fadedPen = new Pen(Color.FromArgb(80, 0, 0, 0), 2))
                        {
                            e.Graphics.FillEllipse(fadedBrush, pt.X - 7, pt.Y - 7, 14, 14);
                            e.Graphics.DrawEllipse(fadedPen, pt.X - 7, pt.Y - 7, 14, 14);
                        }
                    }
                    else
                    {
                        e.Graphics.FillEllipse(redBrush, pt.X - 7, pt.Y - 7, 14, 14);
                        e.Graphics.DrawEllipse(blackPen, pt.X - 7, pt.Y - 7, 14, 14);
                    }
                }
            }

            // 繪製用戶點擊的點（用藍色圓圈高亮）
            var dots = isFront ? frontDots : backDots;
            if (dots.Count > 0)
            {
                using (var highlightPen = new Pen(Color.FromArgb(37, 99, 235), 3))
                {
                    foreach (var dot in dots)
                    {
                        var x = dot.X * canvas.Width;
                        var y = dot.Y * canvas.Height;
                        e.Graphics.DrawEllipse(highlightPen, (float)(x - 12), (float)(y - 12), 24, 24);
                    }
                }
            }
        }

        // 清除所有標記
        private void btnClear_Click(object sender, EventArgs e)
        {
            if (!selectionLocked) return;

            selectionLocked = false;
            selectedKey = null;

            frontDots.Clear();
            backDots.Clear();

            // 移除最後添加的訪問記錄
            if (lastVisitIndex.HasValue && lastVisitIndex.Value >= 0 && lastVisitIndex.Value < visits.Count)
            {
                if (visits[lastVisitIndex.Value].Label == lastVisitLabel)
                {
                    visits.RemoveAt(lastVisitIndex.Value);
                }
            }

            lastVisitIndex = null;
            lastVisitLabel = null;

            UpdateVisitsList();
            picFront.Invalidate();
            picBack.Invalidate();

            // 更新按鈕狀態
            btnClear.Enabled = false;
            btnConfirm.Enabled = false;
        }

        // 確認並保存選擇的位置
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (!selectionLocked || (frontDots.Count == 0 && backDots.Count == 0))
            {
                MessageBox.Show("請先選擇一個部位！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            // 這裡可以將前後標記的資料保存或提交到其他地方
            string message = $"已確認選擇部位：{lastVisitLabel}\n";
            message += $"日期：{DateTime.Today:yyyy-MM-dd}";

            MessageBox.Show(message, "選擇已確認", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // 可以在這裡添加跳轉到下一頁的邏輯
            // 例如：導航到連接設備頁面
            this.Hide();
            var connectForm = new ConnectDeviceForm(_data, lastVisitLabel);
            // var connectForm = new ConnectDeviceForm();
            connectForm.ShowDialog();
            this.Close();
        }

        // 返回上一頁
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public class Dot
        {
            public float X { get; set; }
            public float Y { get; set; }
            public string Label { get; set; }
        }

        private class Visit
        {
            public string Label { get; set; } = "";
            public DateTime Date { get; set; }
        }
    }
}