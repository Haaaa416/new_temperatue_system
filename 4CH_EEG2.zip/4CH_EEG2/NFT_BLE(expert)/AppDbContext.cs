﻿using System;
using System.Data.Entity;  // 引用 Entity Framework 6

namespace NFT_BLE_expert_
{
    // DbContext 類別，用來操作資料庫中的資料表
    public class AppDbContext : DbContext
    {
        // 建構子，接收 DbContextOptions 參數
        public AppDbContext() : base("name=DefaultConnection") { }

        // 定義資料表 Users
        public DbSet<User> Users { get; set; }

        // 定義資料表 Patients
        public DbSet<Patient> Patients { get; set; }
    }

    // 定義 User 類別
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Role { get; set; }
    }

    // 定義 Patient 類別
    public class Patient
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Dob { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string Blood { get; set; }
        public int Height { get; set; }
        public int Weight { get; set; }
    }
}
