﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Xml.Linq;

namespace NFT_BLE_expert_
{
    public partial class RegisterFrom : Form
    {
        // Placeholder 設定
        private readonly string PlaceholderName = "Enter Name";
        private readonly string PlaceholderId = "Enter ID";
        internal readonly Color PlaceholderColor = Color.Silver;
        private readonly Color NormalColor = Color.Black;

        public RegisterFrom()
        {
            InitializeComponent();
            InitRoleOptions();
            InitPlaceholders();

            // 初次載入時置中元件
            RegisterFrom_Resize(this, EventArgs.Empty);
            this.Resize += RegisterFrom_Resize; // 窗體大小變化時重新置中
        }

        private void InitRoleOptions()
        {
            cboRole.Items.Clear();
            cboRole.Items.AddRange(new object[]
            {
                "Doctor",
                "Nurse",
                "Patient",
                "Admin"
            });
            cboRole.SelectedIndex = 0;
        }

        private void InitPlaceholders()
        {
            // Name
            txtName.ForeColor = PlaceholderColor;
            txtName.Text = PlaceholderName;

            // ID
            txtId.ForeColor = PlaceholderColor;
            txtId.Text = PlaceholderId;

            // 事件
            txtName.Enter += (s, e) => RemovePlaceholder(txtName, PlaceholderName);
            txtName.Leave += (s, e) => SetPlaceholder(txtName, PlaceholderName);

            txtId.Enter += (s, e) => RemovePlaceholder(txtId, PlaceholderId);
            txtId.Leave += (s, e) => SetPlaceholder(txtId, PlaceholderId);
        }

        private void panelCard_Paint(object sender, PaintEventArgs e)
        {
            // 設置圓角半徑和顏色
            int radius = 30;
            Color borderColor = Color.Black;  // 設置邊框顏色為黑色

            // 設置圓角邊框
            using (Pen pen = new Pen(borderColor, 2))  // 2 是邊框寬度
            {
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e.Graphics.DrawArc(pen, 0, 0, radius, radius, 180, 90);  // 左上角
                e.Graphics.DrawArc(pen, this.panelCard.Width - radius - 1, 0, radius, radius, 270, 90);  // 右上角
                e.Graphics.DrawArc(pen, this.panelCard.Width - radius - 1, this.panelCard.Height - radius - 1, radius, radius, 0, 90);  // 右下角
                e.Graphics.DrawArc(pen, 0, this.panelCard.Height - radius - 1, radius, radius, 90, 90);  // 左下角

                // 四邊的直線
                e.Graphics.DrawLine(pen, radius / 2, 0, this.panelCard.Width - radius / 2 - 1, 0);  // 上邊
                e.Graphics.DrawLine(pen, radius / 2, this.panelCard.Height - 1, this.panelCard.Width - radius / 2 - 1, this.panelCard.Height - 1);  // 下邊
                e.Graphics.DrawLine(pen, 0, radius / 2, 0, this.panelCard.Height - radius / 2 - 1);  // 左邊
                e.Graphics.DrawLine(pen, this.panelCard.Width - 1, radius / 2, this.panelCard.Width - 1, this.panelCard.Height - radius / 2 - 1);  // 右邊
            }
        }


        private void RemovePlaceholder(TextBox tb, string ph)
        {
            if (tb.ForeColor == PlaceholderColor && tb.Text == ph)
            {
                tb.Text = "";
                tb.ForeColor = NormalColor;
            }
        }

        private void SetPlaceholder(TextBox tb, string ph)
        {
            if (string.IsNullOrWhiteSpace(tb.Text))
            {
                tb.ForeColor = PlaceholderColor;
                tb.Text = ph;
            }
        }

        private void RegisterFrom_Resize(object sender, EventArgs e)
        {
            this.lblHeading.Left = (this.ClientSize.Width - this.lblHeading.Width) / 2;
            this.panelCard.Left = (this.ClientSize.Width - this.panelCard.Width) / 2;
        }

        // === Buttons ===

        private void btnBack_Click(object sender, EventArgs e)
        {
            // 返回登入頁
            var prev = new SettingsForm();
            this.Hide();
            prev.FormClosed += (s, args) => this.Close();
            prev.Show();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 取得有效文字（排除 placeholder）
            string name = (txtName.ForeColor == PlaceholderColor) ? "" : txtName.Text.Trim();
            string id = (txtId.ForeColor == PlaceholderColor) ? "" : txtId.Text.Trim();
            string role = cboRole.SelectedItem?.ToString() ?? "";

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("請輸入 Name。", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtName.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(id))
            {
                MessageBox.Show("請輸入 ID。", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtId.Focus();
                return;
            }

            // TODO: 在此寫入你的資料（檔案 / DB）

            MessageBox.Show($"新增成功：\nName: {name}\nID: {id}\nRole: {role}",
                "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // 新增成功 → 直接跳到 PatientsFrom
            var next = new PatientsForm();           // 若要帶資料，可改成 new PatientsFrom(name, id, role)
            this.Hide();
            next.FormClosed += (s, args) => this.Close();
            next.Show();
        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }
    }
}
