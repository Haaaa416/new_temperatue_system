﻿using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace NFT_BLE_expert_
{
    public partial class PatientsDetailForm : Form
    {
        private readonly PatientsForm.PatientCardData _data;

        public PatientsDetailForm(PatientsForm.PatientCardData data)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            // 上方頭像＋基本資訊
            lblName.Text = _data.Name;
            lblId.Text = _data.Id;

            try
            {
                if (!string.IsNullOrWhiteSpace(_data.AvatarPath) && File.Exists(_data.AvatarPath))
                {
                    using (var fs = new FileStream(_data.AvatarPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                        picAvatar.Image = Image.FromStream(fs);
                }
            }
            catch { /* ignore load image errors */ }

            // 詳細欄位
            lblDob.Text = _data.Dob.ToString("yyyy/MM/dd");
            lblAge.Text = _data.Age.ToString();
            lblGender.Text = _data.Gender;
            lblBlood.Text = _data.Blood;
            lblHeight.Text = _data.Height.ToString();
            lblWeight.Text = _data.Weight.ToString();
        }

        // 返回清單 → 關閉自己，讓呼叫端(PatientsFrom)繼續顯示
        private void btnBack_Click(object sender, EventArgs e)
        {
            // 把清單叫回來
            if (this.Owner != null) this.Owner.Show();
            this.Close(); // 關掉詳細頁
        }



        // 確認 → 回傳 OK，呼叫端依據 OK 再開 SelectionPositionsFrom
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            // 若要先關掉詳細頁再進下一頁（常見的導覽行為）
            this.Hide();
            using (var sel = new SelectionPositionsFrom(_data))
            {
                sel.StartPosition = FormStartPosition.CenterScreen;
                sel.ShowDialog();
            }
            this.Close();
        }

    }
}
