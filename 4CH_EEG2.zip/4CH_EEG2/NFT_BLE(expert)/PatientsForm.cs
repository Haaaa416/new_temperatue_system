﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace NFT_BLE_expert_
{
    public partial class PatientsForm : Form
    {
        // 只有病人頭像還是用檔案（男女不同）；其餘 icons 改用 Resources
        private const string ImgDir = @"C:\Users\user\4CH_EEG\4CH_EEG\NFT_BLE(expert)\Resources";
        private const int CardMargin = 8;

        public PatientsForm()
        {
            InitializeComponent();

            InitTopBarImages();   // 品牌、登入者頭像、icons 與事件
            InitCombos();

            // DOB 變更→自動算年齡
            dtpDob.ValueChanged += (_, __) => tbAge.Text = ComputeAge(dtpDob.Value).ToString();

            // 左欄寬度變更→卡片維持兩欄
            flpPatients.SizeChanged += (_, __) => ReflowCards();

          
        }


        /* ---------- 初始化：頂端圖示 ---------- */
        private void InitTopBarImages()
        {
            // 品牌與登入者頭像（沿用你的檔案方式，找不到就忽略）
            TryLoad(picBrand, Path.Combine(ImgDir, "logo.png"));
            TryLoad(picAvatar, Path.Combine(ImgDir, "doctor_1.png"));

            string settingImagePath = @"C:\Users\user\4CH_EEG\4CH_EEG\NFT_BLE(expert)\Resources\setting.png";
            string notificationImagePath = @"C:\Users\user\4CH_EEG\4CH_EEG\NFT_BLE(expert)\Resources\notification.png";

            if (File.Exists(settingImagePath))
                btnGear.Image = Image.FromFile(settingImagePath);  // 加載設定圖像

            if (File.Exists(notificationImagePath))
                btnBell.Image = Image.FromFile(notificationImagePath);  // 加載通知圖像

            // 設定按鈕樣式
            btnBell.ImageAlign = ContentAlignment.MiddleCenter;
            btnGear.ImageAlign = ContentAlignment.MiddleCenter;

            btnBell.Size = new Size(36, 36);
            btnGear.Size = new Size(36, 36);

            // 按鈕點擊事件
            btnBell.Click += BtnBell_Click;
            btnGear.Click += BtnGear_Click;
        }

        /* ---------- 初始化：右側欄位 ---------- */
        private void InitCombos()
        {
            cboGender.Items.AddRange(new object[] { "Male", "Female" });
            if (cboGender.Items.Count > 0) cboGender.SelectedIndex = 0;

            cboBlood.Items.AddRange(new object[] { "A", "B", "O", "AB" });
            if (cboBlood.Items.Count > 0) cboBlood.SelectedIndex = 0;

            dtpDob.Format = DateTimePickerFormat.Custom;
            dtpDob.CustomFormat = "yyyy/MM/dd";

            // 初始年齡
            tbAge.Text = ComputeAge(dtpDob.Value).ToString();
        }

        /* ---------- 共用：讀檔放圖（讀不到就忽略） ---------- */
        private static void TryLoad(PictureBox pb, string path)
        {
            try
            {
                if (File.Exists(path))
                {
                    using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                        pb.Image = Image.FromStream(fs);
                }
            }
            catch { /* ignore */ }
        }

        /* ---------- 右側按鈕 ---------- */
        private void btnLogout_Click(object sender, EventArgs e) => Close();

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // 基本驗證
            if (string.IsNullOrWhiteSpace(tbName.Text))
            {
                MessageBox.Show("請輸入姓名", "提醒");
                tbName.Focus();
                return;
            }
            if (dtpDob.Value.Date > DateTime.Today)
            {
                MessageBox.Show("出生年月日不能是未來", "提醒");
                dtpDob.Focus();
                return;
            }
            if (!int.TryParse(tbAge.Text.Trim(), out var age) || age < 0 || age > 120)
            {
                MessageBox.Show("年齡格式錯誤", "提醒");
                tbAge.Focus();
                return;
            }
            if (!int.TryParse(tbHeight.Text.Trim(), out var h) || h <= 0 || h > 300)
            {
                MessageBox.Show("身高格式錯誤（1~300）", "提醒");
                tbHeight.Focus();
                return;
            }
            if (!int.TryParse(tbWeight.Text.Trim(), out var w) || w <= 0 || w > 1000)
            {
                MessageBox.Show("體重格式錯誤（1~1000）", "提醒");
                tbWeight.Focus();
                return;
            }

            // ID：PAT-2025-XXXX
            var rnd = new Random();
            var id = $"PAT-2025-{rnd.Next(0, 10000):0000}";

            // 依性別決定卡片頭像
            var avatarPath = cboGender.Text == "Female"
                ? Path.Combine(ImgDir, "patient_2.png")
                : Path.Combine(ImgDir, "patient_1.png");

            // 建卡 & 加到左欄
            var data = new PatientCardData
            {
                Id = id,
                Name = tbName.Text.Trim(),
                Dob = dtpDob.Value.Date,
                Age = age,
                Gender = cboGender.Text,
                Blood = cboBlood.Text,
                Height = h,
                Weight = w,
                AvatarPath = avatarPath
            };
            AddPatientCard(data);

            // 清除欄位（年齡會跟 DOB 自動算）
            tbName.Clear();
            tbHeight.Clear();
            tbWeight.Clear();

            MessageBox.Show("新增成功！", "完成");
        }

        /* ---------- 左欄：新增卡片、兩欄自動排 ---------- */
        private void AddPatientCard(PatientCardData data)
        {
            if (lblEmpty.Visible) lblEmpty.Visible = false;

            var card = new Panel
            {
                Height = 88,
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(CardMargin),
                Cursor = Cursors.Hand,
                Tag = data
            };

            var avatar = new PictureBox
            {
                Width = 48,
                Height = 48,
                Left = 12,
                Top = 16,
                SizeMode = PictureBoxSizeMode.Zoom
            };
            TryLoad(avatar, data.AvatarPath);

            var lblName = new Label
            {
                AutoSize = false,
                Left = 72,
                Top = 12,
                Width = 220,
                Height = 24,
                Text = data.Name,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };

            var lblId = new Label
            {
                AutoSize = true,
                Left = 72,
                Top = 38,
                ForeColor = Color.FromArgb(90, 90, 90),
                Font = new Font("Segoe UI", 9, FontStyle.Regular),
                Text = $"ID : {data.Id}"
            };

            card.Controls.Add(avatar);
            card.Controls.Add(lblName);
            card.Controls.Add(lblId);

            // 點卡：跳詳細頁
            card.Click += (_, __) => OpenDetail((PatientCardData)card.Tag);
            foreach (Control c in card.Controls) c.Click += (_, __) => OpenDetail((PatientCardData)card.Tag);

            flpPatients.Controls.Add(card);

            // 依目前寬度重新計算卡片寬，維持兩欄
            ReflowCards();
        }

        private void ReflowCards()
        {
            if (flpPatients.Controls.Count == 0) return;

            var total = flpPatients.ClientSize.Width;
            var oneWidth = Math.Max(260, (total - CardMargin * 6) / 2); // 兩欄；留邊距
            foreach (var p in flpPatients.Controls.OfType<Panel>())
                p.Width = oneWidth;
        }

        private void OpenDetail(PatientCardData data)
        {
            var f = new PatientsDetailForm(data)
            {
                StartPosition = FormStartPosition.CenterScreen
            };

            // 詳細頁關閉時，把清單重新顯示（沿用同一個實例，資料不會消失）
            f.FormClosed += (_, __) => this.Show();

            // 先把清單隱藏，再開詳細頁，並把清單設成 Owner
            this.Hide();
            f.Show(this);
        }

        /* ---------- setting / notification ---------- */
        // Event handler for btnBell (Notification button)
        private void BtnBell_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Currently no new notifications.", "Notifications", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Event handler for btnGear (Settings button)
        private void BtnGear_Click(object sender, EventArgs e)
        {
            // Show help or settings dialog
            using (var overlay = new Form())
            using (var card = new Form())
            {
                // Set up the overlay (semi-transparent background)
                overlay.StartPosition = FormStartPosition.Manual;
                overlay.FormBorderStyle = FormBorderStyle.None;
                overlay.Bounds = Screen.FromControl(this).Bounds;
                overlay.BackColor = Color.Black;
                overlay.Opacity = 0.5;
                overlay.ShowInTaskbar = false;
                overlay.TopMost = true;

                // Set up the content card (white dialog box)
                card.StartPosition = FormStartPosition.CenterParent;
                card.FormBorderStyle = FormBorderStyle.FixedSingle;
                card.Size = new Size(520, 380);
                card.BackColor = Color.White;
                card.TopMost = true;
                card.ShowInTaskbar = false;
                card.Text = "Usage Instructions";

                var lbl = new Label
                {
                    AutoSize = false,
                    Dock = DockStyle.Fill,
                    Padding = new Padding(20),
                    Font = new Font("Segoe UI", 10),
                    Text = @"Instructions:
• Left panel: After entering patient information and clicking ADD, the patient details and system-generated ID will be displayed.

Input restrictions:
• Date of birth: Cannot be a future date.
• Height: Cannot be negative and must be less than 300 cm.
• Weight: Cannot be negative and must be less than 1000 kg.
• Name: Required field, cannot be empty."

                };

                var btnClose = new Button
                {
                    Text = "Close",
                    Anchor = AnchorStyles.Bottom | AnchorStyles.Right,
                    Size = new Size(90, 32),
                    Location = new Point(card.ClientSize.Width - 110, card.ClientSize.Height - 50)
                };
                btnClose.Click += (_, __) => card.Close();

                card.Controls.Add(lbl);
                card.Controls.Add(btnClose);

                overlay.Show(this); // Show overlay first
                card.ShowDialog(overlay); // Show content card (parent is overlay)
                overlay.Close(); // Close overlay
            }
        }

        /* ---------- 小工具 ---------- */
        private static int ComputeAge(DateTime dob)
        {
            var today = DateTime.Today;
            var age = today.Year - dob.Year;
            if (dob.Date > today.AddYears(-age)) age--;
            return Math.Max(age, 0);
        }

        /* ---------- 卡片資料模型 ---------- */
        public class PatientCardData
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public DateTime Dob { get; set; }
            public int Age { get; set; }
            public string Gender { get; set; }
            public string Blood { get; set; }
            public int Height { get; set; }
            public int Weight { get; set; }
            public string AvatarPath { get; set; }
        }

        private void flpPatients_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
