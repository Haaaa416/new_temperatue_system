﻿using System.Windows.Forms;
using System.Drawing;

namespace NFT_BLE_expert_
{
    partial class PatientsForm
    {
        private System.ComponentModel.IContainer components = null;

        // Top bar
        private Panel pnlTop;
        private PictureBox picBrand;
        private Label lblBrand;
        private Button btnBell;
        private Button btnGear;
        private PictureBox picAvatar;
        private Label lblUser;
        private Button btnLogout;

        // Layout
        private TableLayoutPanel tableMain;

        // Left list
        private FlowLayoutPanel flpPatients;
        private Label lblEmpty;

        // Right form
        private Panel pnlRight;
        private Label lblPanelTitle;
        private Panel pnlFormCard;

        private Label labelName;
        private TextBox tbName;

        private Label labelDob;
        private DateTimePicker dtpDob;

        private Label labelAge;
        private TextBox tbAge;

        private Label labelGender;
        private ComboBox cboGender;

        private Label labelBlood;
        private ComboBox cboBlood;

        private Label labelHeight;
        private TextBox tbHeight;

        private Label labelWeight;
        private TextBox tbWeight;

        private Button btnAdd;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.pnlTop = new Panel();
            this.picBrand = new PictureBox();
            this.lblBrand = new Label();
            this.btnBell = new Button();
            this.btnGear = new Button();
            this.picAvatar = new PictureBox();
            this.lblUser = new Label();
            this.btnLogout = new Button();

            this.tableMain = new TableLayoutPanel();

            this.flpPatients = new FlowLayoutPanel();
            this.lblEmpty = new Label();

            this.pnlRight = new Panel();
            this.lblPanelTitle = new Label();
            this.pnlFormCard = new Panel();

            this.labelName = new Label();
            this.tbName = new TextBox();

            this.labelDob = new Label();
            this.dtpDob = new DateTimePicker();

            this.labelAge = new Label();
            this.tbAge = new TextBox();

            this.labelGender = new Label();
            this.cboGender = new ComboBox();

            this.labelBlood = new Label();
            this.cboBlood = new ComboBox();

            this.labelHeight = new Label();
            this.tbHeight = new TextBox();

            this.labelWeight = new Label();
            this.tbWeight = new TextBox();

            this.btnAdd = new Button();

            ((System.ComponentModel.ISupportInitialize)(this.picBrand)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();

            // ========= Form =========
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(1480, 820);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Patients";
            this.BackColor = Color.White;

            // ========= Top bar =========
            this.pnlTop.Dock = DockStyle.Top;
            this.pnlTop.Height = 56;
            this.pnlTop.BackColor = Color.White;
            this.pnlTop.Padding = new Padding(20, 6, 20, 6);

            // logo
            this.picBrand.Location = new Point(20, 10);
            this.picBrand.Size = new Size(32, 32);
            this.picBrand.SizeMode = PictureBoxSizeMode.Zoom;

            this.lblBrand.AutoSize = true;
            this.lblBrand.Location = new Point(58, 14);
            this.lblBrand.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            this.lblBrand.Text = "BATC";

            this.btnBell.FlatStyle = FlatStyle.Flat;
            this.btnBell.FlatAppearance.BorderSize = 0;
            this.btnBell.Width = 36; this.btnBell.Height = 36;
            this.btnBell.Location = new Point(1180, 10);

            this.btnGear.FlatStyle = FlatStyle.Flat;
            this.btnGear.FlatAppearance.BorderSize = 0;
            this.btnGear.Width = 36; this.btnGear.Height = 36;
            this.btnGear.Location = new Point(1220, 10);

            this.picAvatar.Location = new Point(1266, 10);
            this.picAvatar.Size = new Size(32, 32);
            this.picAvatar.SizeMode = PictureBoxSizeMode.Zoom;

            this.lblUser.AutoSize = true;
            this.lblUser.Location = new Point(1305, 17);
            this.lblUser.Font = new Font("Segoe UI", 10F);
            this.lblUser.Text = "Dr. Wang";

            this.btnLogout.Text = "Log out";
            this.btnLogout.BackColor = Color.FromArgb(191, 191, 191);
            this.btnLogout.ForeColor = Color.White;
            this.btnLogout.FlatStyle = FlatStyle.Flat;
            this.btnLogout.FlatAppearance.BorderSize = 0;
            this.btnLogout.Location = new Point(1380, 12);
            this.btnLogout.Size = new Size(80, 30);
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);

            this.pnlTop.Controls.Add(this.picBrand);
            this.pnlTop.Controls.Add(this.lblBrand);
            this.pnlTop.Controls.Add(this.btnBell);
            this.pnlTop.Controls.Add(this.btnGear);
            this.pnlTop.Controls.Add(this.picAvatar);
            this.pnlTop.Controls.Add(this.lblUser);
            this.pnlTop.Controls.Add(this.btnLogout);

            // ========= Main table =========
            this.tableMain.Dock = DockStyle.Fill;
            this.tableMain.Padding = new Padding(20);
            this.tableMain.ColumnCount = 2;
            this.tableMain.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45F)); // 左邊列表
            this.tableMain.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55F)); // 右邊表單
            this.tableMain.RowCount = 1;
            this.tableMain.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));

            // ========= Left list =========
            this.flpPatients.Dock = DockStyle.Fill;
            this.flpPatients.BackColor = Color.WhiteSmoke;
            this.flpPatients.AutoScroll = true;
            this.flpPatients.Padding = new Padding(8);
            this.flpPatients.WrapContents = true;
            this.flpPatients.FlowDirection = FlowDirection.LeftToRight;

            this.lblEmpty.AutoSize = false;
            this.lblEmpty.Text = "目前沒有病人資料";
            this.lblEmpty.TextAlign = ContentAlignment.MiddleCenter;
            this.lblEmpty.ForeColor = Color.FromArgb(138, 143, 152);
            this.lblEmpty.BorderStyle = BorderStyle.FixedSingle;
            this.lblEmpty.BackColor = Color.White;
            this.lblEmpty.Width = 520;
            this.lblEmpty.Height = 560;
            this.lblEmpty.Margin = new Padding(8);
            this.flpPatients.Controls.Add(this.lblEmpty);

            // ========= Right panel =========
            this.pnlRight.Dock = DockStyle.Fill;
            this.pnlRight.BackColor = Color.White;

            this.lblPanelTitle.Text = "Add Patient";
            this.lblPanelTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            this.lblPanelTitle.AutoSize = false;
            this.lblPanelTitle.Width = 240;
            this.lblPanelTitle.Height = 44;
            this.lblPanelTitle.TextAlign = ContentAlignment.MiddleCenter;
            this.lblPanelTitle.BorderStyle = BorderStyle.FixedSingle;
            this.lblPanelTitle.Location = new Point(24, 8);

            this.pnlFormCard.Location = new Point(24, 60);
            this.pnlFormCard.Size = new Size(760, 540);
            this.pnlFormCard.BackColor = Color.White;
            this.pnlFormCard.BorderStyle = BorderStyle.FixedSingle;
            this.pnlFormCard.Padding = new Padding(24);

            int labelW = 120;
            int inputW = 560;
            int rowH = 44;
            int rowGap = 14;
            int y = 10;

            // Name
            this.labelName.Text = "Name:";
            this.labelName.Location = new Point(10, y + 10);
            this.labelName.Size = new Size(labelW, 24);
            this.tbName.Location = new Point(10 + labelW + 12, y);
            this.tbName.Size = new Size(inputW, 30);
            y += rowH + rowGap;

            // DOB
            this.labelDob.Text = "Date of Birth:";
            this.labelDob.Location = new Point(10, y + 10);
            this.labelDob.Size = new Size(labelW, 24);
            this.dtpDob.Location = new Point(10 + labelW + 12, y);
            this.dtpDob.Size = new Size(inputW, 30);
            y += rowH + rowGap;

            // Age（唯讀，跟 DOB 同步）
            this.labelAge.Text = "Age:";
            this.labelAge.Location = new Point(10, y + 10);
            this.labelAge.Size = new Size(labelW, 24);
            this.tbAge.Location = new Point(10 + labelW + 12, y);
            this.tbAge.Size = new Size(inputW, 30);
            this.tbAge.ReadOnly = true;
            y += rowH + rowGap;

            // Gender
            this.labelGender.Text = "Gender:";
            this.labelGender.Location = new Point(10, y + 10);
            this.labelGender.Size = new Size(labelW, 24);
            this.cboGender.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cboGender.Location = new Point(10 + labelW + 12, y);
            this.cboGender.Size = new Size(inputW, 30);
            y += rowH + rowGap;

            // Blood
            this.labelBlood.Text = "Blood Type:";
            this.labelBlood.Location = new Point(10, y + 10);
            this.labelBlood.Size = new Size(labelW, 24);
            this.cboBlood.DropDownStyle = ComboBoxStyle.DropDownList;
            this.cboBlood.Location = new Point(10 + labelW + 12, y);
            this.cboBlood.Size = new Size(inputW, 30);
            y += rowH + rowGap;

            // Height
            this.labelHeight.Text = "Height(cm):";
            this.labelHeight.Location = new Point(10, y + 10);
            this.labelHeight.Size = new Size(labelW, 24);
            this.tbHeight.Location = new Point(10 + labelW + 12, y);
            this.tbHeight.Size = new Size(inputW, 30);
            y += rowH + rowGap;

            // Weight
            this.labelWeight.Text = "Weight(kg):";
            this.labelWeight.Location = new Point(10, y + 10);
            this.labelWeight.Size = new Size(labelW, 24);
            this.tbWeight.Location = new Point(10 + labelW + 12, y);
            this.tbWeight.Size = new Size(inputW, 30);
            y += rowH + 18;

            // ADD button（置中）
            this.btnAdd.Text = "ADD";
            this.btnAdd.Size = new Size(140, 44);
            this.btnAdd.Location = new Point((this.pnlFormCard.Width - this.btnAdd.Width) / 2, y);
            this.btnAdd.FlatStyle = FlatStyle.Flat;
            this.btnAdd.FlatAppearance.BorderSize = 1;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);



            // form card
            this.pnlFormCard.Controls.Add(this.labelName);
            this.pnlFormCard.Controls.Add(this.tbName);
            this.pnlFormCard.Controls.Add(this.labelDob);
            this.pnlFormCard.Controls.Add(this.dtpDob);
            this.pnlFormCard.Controls.Add(this.labelAge);
            this.pnlFormCard.Controls.Add(this.tbAge);
            this.pnlFormCard.Controls.Add(this.labelGender);
            this.pnlFormCard.Controls.Add(this.cboGender);
            this.pnlFormCard.Controls.Add(this.labelBlood);
            this.pnlFormCard.Controls.Add(this.cboBlood);
            this.pnlFormCard.Controls.Add(this.labelHeight);
            this.pnlFormCard.Controls.Add(this.tbHeight);
            this.pnlFormCard.Controls.Add(this.labelWeight);
            this.pnlFormCard.Controls.Add(this.tbWeight);
            this.pnlFormCard.Controls.Add(this.btnAdd);

            // 右側
            this.pnlRight.Controls.Add(this.lblPanelTitle);
            this.pnlRight.Controls.Add(this.pnlFormCard);

            // 放入主表
            this.tableMain.Controls.Add(this.flpPatients, 0, 0);
            this.tableMain.Controls.Add(this.pnlRight, 1, 0);

            // 最終加入
            this.Controls.Add(this.tableMain);
            this.Controls.Add(this.pnlTop);

            ((System.ComponentModel.ISupportInitialize)(this.picBrand)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
        }
    }
}
