﻿namespace NFT_BLE_expert_
{
    partial class PatientsDetailForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel card;
        private System.Windows.Forms.PictureBox picAvatar;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblId;

        private System.Windows.Forms.Label capDob;
        private System.Windows.Forms.Label capAge;
        private System.Windows.Forms.Label capGender;
        private System.Windows.Forms.Label capBlood;
        private System.Windows.Forms.Label capHeight;
        private System.Windows.Forms.Label capWeight;

        private System.Windows.Forms.Label lblDob;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblGender;
        private System.Windows.Forms.Label lblBlood;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblWeight;

        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Panel divider;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();

            this.card = new System.Windows.Forms.Panel();
            this.picAvatar = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            this.lblId = new System.Windows.Forms.Label();

            this.capDob = new System.Windows.Forms.Label();
            this.capAge = new System.Windows.Forms.Label();
            this.capGender = new System.Windows.Forms.Label();
            this.capBlood = new System.Windows.Forms.Label();
            this.capHeight = new System.Windows.Forms.Label();
            this.capWeight = new System.Windows.Forms.Label();

            this.lblDob = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblGender = new System.Windows.Forms.Label();
            this.lblBlood = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblWeight = new System.Windows.Forms.Label();

            this.divider = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).BeginInit();

            // ==== Form ====
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1480, 820);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Patient Detail";
            this.BackColor = System.Drawing.Color.White;

            // ==== Card ====
            this.card.BackColor = System.Drawing.Color.White;
            this.card.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.card.Size = new System.Drawing.Size(760, 300);
            this.card.Location = new System.Drawing.Point(360,260);

            // avatar
            this.picAvatar.Size = new System.Drawing.Size(64, 64);
            this.picAvatar.Location = new System.Drawing.Point(24, 22);
            this.picAvatar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;

            // name
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblName.Location = new System.Drawing.Point(100, 22);
            this.lblName.Text = "Name";

            // id
            this.lblId.AutoSize = true;
            this.lblId.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblId.ForeColor = System.Drawing.Color.DimGray;
            this.lblId.Location = new System.Drawing.Point(102, 50);
            this.lblId.Text = "ID : PAT-2025-0000";

            // divider
            this.divider.BackColor = System.Drawing.Color.Gainsboro;
            this.divider.Location = new System.Drawing.Point(24, 100);
            this.divider.Size = new System.Drawing.Size(710, 1);

            // captions (left column)
            int capX = 48, valX = 200, rowY = 120, rowH = 40;

            this.capDob.Text = "Date of Birth";
            this.capDob.Location = new System.Drawing.Point(capX, rowY);
            this.capDob.Size = new System.Drawing.Size(130, 24);
            this.capDob.Font = new System.Drawing.Font("Segoe UI", 10F);

            this.lblDob.Text = "-";
            this.lblDob.Location = new System.Drawing.Point(valX, rowY);
            this.lblDob.Size = new System.Drawing.Size(200, 24);
            this.lblDob.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            rowY += rowH;

            this.capGender.Text = "Gender";
            this.capGender.Location = new System.Drawing.Point(capX, rowY);
            this.capGender.Size = new System.Drawing.Size(130, 24);
            this.capGender.Font = new System.Drawing.Font("Segoe UI", 10F);

            this.lblGender.Text = "-";
            this.lblGender.Location = new System.Drawing.Point(valX, rowY);
            this.lblGender.Size = new System.Drawing.Size(200, 24);
            this.lblGender.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            rowY += rowH;

            this.capHeight.Text = "Height(cm)";
            this.capHeight.Location = new System.Drawing.Point(capX, rowY);
            this.capHeight.Size = new System.Drawing.Size(130, 24);
            this.capHeight.Font = new System.Drawing.Font("Segoe UI", 10F);

            this.lblHeight.Text = "-";
            this.lblHeight.Location = new System.Drawing.Point(valX, rowY);
            this.lblHeight.Size = new System.Drawing.Size(200, 24);
            this.lblHeight.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            // right column
            int capX2 = 420, valX2 = 570; rowY = 120;

            this.capAge.Text = "Age";
            this.capAge.Location = new System.Drawing.Point(capX2, rowY);
            this.capAge.Size = new System.Drawing.Size(130, 24);
            this.capAge.Font = new System.Drawing.Font("Segoe UI", 10F);

            this.lblAge.Text = "-";
            this.lblAge.Location = new System.Drawing.Point(valX2, rowY);
            this.lblAge.Size = new System.Drawing.Size(150, 24);
            this.lblAge.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            rowY += rowH;

            this.capBlood.Text = "Blood Type";
            this.capBlood.Location = new System.Drawing.Point(capX2, rowY);
            this.capBlood.Size = new System.Drawing.Size(130, 24);
            this.capBlood.Font = new System.Drawing.Font("Segoe UI", 10F);

            this.lblBlood.Text = "-";
            this.lblBlood.Location = new System.Drawing.Point(valX2, rowY);
            this.lblBlood.Size = new System.Drawing.Size(150, 24);
            this.lblBlood.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            rowY += rowH;

            this.capWeight.Text = "Weight(kg)";
            this.capWeight.Location = new System.Drawing.Point(capX2, rowY);
            this.capWeight.Size = new System.Drawing.Size(130, 24);
            this.capWeight.Font = new System.Drawing.Font("Segoe UI", 10F);

            this.lblWeight.Text = "-";
            this.lblWeight.Location = new System.Drawing.Point(valX2, rowY);
            this.lblWeight.Size = new System.Drawing.Size(150, 24);
            this.lblWeight.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            // Buttons
            this.btnBack.Text = "返回清單";
            this.btnBack.Size = new System.Drawing.Size(120, 36);
            this.btnBack.Location = new System.Drawing.Point(this.card.Left + 180, this.card.Bottom + 20);
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);

            this.btnConfirm.Text = "確認";
            this.btnConfirm.Size = new System.Drawing.Size(120, 36);
            this.btnConfirm.Location = new System.Drawing.Point(this.card.Right - 180 - 120, this.card.Bottom + 20);
            this.btnConfirm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);

            // add to card
            this.card.Controls.Add(this.picAvatar);
            this.card.Controls.Add(this.lblName);
            this.card.Controls.Add(this.lblId);
            this.card.Controls.Add(this.divider);

            this.card.Controls.Add(this.capDob);
            this.card.Controls.Add(this.lblDob);
            this.card.Controls.Add(this.capGender);
            this.card.Controls.Add(this.lblGender);
            this.card.Controls.Add(this.capHeight);
            this.card.Controls.Add(this.lblHeight);

            this.card.Controls.Add(this.capAge);
            this.card.Controls.Add(this.lblAge);
            this.card.Controls.Add(this.capBlood);
            this.card.Controls.Add(this.lblBlood);
            this.card.Controls.Add(this.capWeight);
            this.card.Controls.Add(this.lblWeight);

            // add to form
            this.Controls.Add(this.card);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnConfirm);

            ((System.ComponentModel.ISupportInitialize)(this.picAvatar)).EndInit();
        }
    }
}
